#include <stdio.h>

int main(){
	/*int a, b, suma, resta; 
	float division;
	
	printf("Ingrese a: ");
	scanf("%d", &a);
	
	printf("\nIngrese b: ");
	scanf("%d", &b);
	
	suma= a+b;
	resta= a-b;
	division= a/b;
	
	printf("\nLa suma es: %d", suma);
	printf("\nLa resta es: %d", resta);
	printf("\nLa division es: %f", division);*/
	
	char letra1, letra2, palabra[10]; 
	
	printf("Ingrese una letra 1: ");
	scanf("%c", &letra1);
	
	getchar();
	
	printf("\n""Ingrese una leta 2: ");
	scanf("%c", &letra2);
	
	printf("\n""La letra 1 es: %c", letra1);
	printf("\n""La letra 2 es: %c", letra2);
	
	printf("\n""Ingrese una palabra: ");
	scanf("%s", palabra);
	
	printf("\n""La palabra es: %s", palabra);
	
	return (0);
}
