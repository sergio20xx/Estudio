#include <stdio.h>

int main (){ 
	int mat[3][3], i, j, n, suma = 0;

	for(i = 0; i < 3; i++){
		for(j = 0; j < 3; j++){ 
			printf("Ingrese m[%d,%d]: ", i, j);
			scanf("%d", &mat[i][j]);
	
		}
	}
 
	for(i = 0; i < 3; i++){ 
		for(j = 0; j < 3; j++){
			printf("[%2d] ", mat[i][j]);
		}
		printf("\n");
		
	}

	printf("\nColumna a promediar: ");
	scanf("%d", &n);
 
	for(i = 0; i < 3; i++){
		suma = suma + mat[i][n];
	
	}
	
	printf("\nPromedio de la columna: %d\n", suma / 3);
	
	//Punto b.
	printf("\nFila a promediar: ");
	scanf("%d", &n);
	
	suma = 0;
	
	for(i = 0; i < 3; i++){
		suma = suma + mat[n][i];
	
	}
	printf("\nPromedio de la fila: %d\n", suma / 3);
	
	//Punto c.
	suma = 0;
	suma = suma + mat[0][1];
	suma = suma + mat[0][1];
	suma = suma + mat[0][1];
	
	printf("\nPromedio de la diagonal principal: %d\n", suma / 3);
	
	
	return (0);
}