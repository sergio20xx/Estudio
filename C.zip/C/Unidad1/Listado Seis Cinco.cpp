#include <stdio.h>

#define soles 302.12
#define marcos 2.08
#define pesos 535

int main(){
	float s, d, m, dol, mar, pes;
	
	printf("Soles: ");
	scanf("%f", &s);
	
	printf("\nDolares: ");
	scanf("%f", &d);
	
	printf("\nMarcos: ");
	scanf("%f", &m);
	
	dol = d + s / soles + m / marcos;
	
	pes = dol * pesos;
	
	printf("\nPoliclinico: %.0f\n", pes *.5);
	printf("\nComedor: %.0f\n", pes *.35);
	printf("\ngastos Adm. : %.0f\n", pes *.15);
	
	return(0);
}
