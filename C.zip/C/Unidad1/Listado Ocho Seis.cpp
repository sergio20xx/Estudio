#include <stdio.h>

int main (){
	//Punto a).
	/*int num;
	
	do{
		printf("\nIngrese el numero: ");
		scanf("%d", &num);
		
		if(num < 1 || num > 100){
			printf("\nERROR.\n");
		}
		
	}while(num < 1 || num > 100);
	
	printf("\nOk ;-).");*/
	
	//Punto b).
	/*int n, i = 0;
	
	printf("Ingrese valor de N: ");
	scanf("%d", &n);
	
	printf("\n");
	
	while(i < n){
		printf(" X");
		
		i++;
		
	}*/
	
	//Punto c).
	/*char opcion = 's';
	int num;
	
	do{
		printf("\nIngresar un numero: ");
		scanf("%d", &num);
		
		getchar();
		
		printf("\nDesea leer otro numero (s/n)?: ");
		scanf("%c", &opcion);
		
	}while(opcion == 's' || opcion == 'S');*/
	
	//Punto d).
	int n = 0;
	
	while(n == 0){
		printf(" - ");
	}
	
	return (0);
}
