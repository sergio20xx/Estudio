#include <stdio.h>

int main (){
	//Punto a).
	/*int n, i;
	
	printf("Ingrese valor de N: ");
	scanf("%d", &n);
	
	for(i = 0; i < n; i++){
		printf(" $");
	}*/
	
	//Punto b).
	/*int punto = 0;
	
	while(punto == 0){
		printf(" .");
		
	}*/
	
	//Punto c).
	/*int x, i;
	
	printf("Valor de X?: ");
	scanf("%d", &x);
	
	for(i = 0; i < x; i++){
		printf(" %d", i+1);
	}*/
	
	//Punto d)
	float num, sum = 0, prom;
	int i;

	for(i = 0; i < 10; i++){
		printf("\nIngrese num%d: ", i+1);
		scanf("%f", &num);
		
		sum = sum + num;
		
	}
	
	prom = sum / 10;
	
	printf("\nEl promedio es: %.1f", prom);
	
	return (0);
}
