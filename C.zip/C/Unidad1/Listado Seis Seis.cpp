#include <stdio.h>

int main (){
	
	float min, seg, cent, met, segundos, km, horas, velocidad;

	printf("Min: ");
	scanf("%f", &min);
	
	printf("Seg: ");
	scanf("%f", &seg);
	
	printf("Cent: ");
	scanf("%f", &cent);
	
	printf("Met: ");
	scanf("%f", &met);
	
	segundos = min * 60 + seg + cent /10;
	
	horas = segundos / 3600;
	
	km = met / 1000;
	
	velocidad = km / horas;
	
	printf("La velocidad es : %.1f Km/h", velocidad);
	
	return(0);
}
