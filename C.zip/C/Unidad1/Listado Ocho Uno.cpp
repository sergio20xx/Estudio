#include <stdio.h>

int main (){
	int num=0, valor;
	
	printf("Ingrese cantidad de pares: ");
	scanf("%d", &valor);
	
	/*while(num != 2 * valor){
		num = num + 2;
		printf("\n%d", num);
		
	}*/
	
	do{	
		printf("\n%d", num);
		num = num + 2;
		
	}while(num <= 12);
	
	return (0);
}
