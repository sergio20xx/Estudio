#include <stdio.h>

int main (){
	/*int num;
	
	printf("Numero: ");
	scanf("%d", &num);
	
	printf("\nUnidad es: %d", num % 10);
	
	printf("\nDecenas: %d", (num / 10) %10);
	
	printf("\nCentenas: %d", (num / 100) % 10);*/
	
	int a, num;
	
	printf("Numero: ");
	scanf("%d", &a);
	
	num = a %10 + (a / 10) % 10 + (a / 100) % 10 + a / 1000;

	printf("\nEl resultado de la suma es: %d", num);
	
	return(0);
}
