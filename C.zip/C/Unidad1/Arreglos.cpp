#include <stdio.h>

int main (){
	float n[5];
	
	for(int i = 0; i <5 ; i++){
		printf("\nIngresar algo: ");
		scanf("%f", &n[i]);
	
	}
	
	printf("\nElementos ingresados: \n");
	
	for(int i = 0; i < 5; i++){
		printf("%.2f\n", n[i]);
		
	}
	
	return (0);
}
