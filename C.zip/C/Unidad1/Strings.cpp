#include <stdio.h>

int main (){
	char nombre[20];
	
	printf("Digame su nombre: ");
	scanf("%s", nombre);
	
	printf("\n%s\n", nombre);
	
	getchar();
	
	printf("\nDiga: ");
	gets(nombre);
	
	printf("\n%s", nombre);
	
	return (0);
}
