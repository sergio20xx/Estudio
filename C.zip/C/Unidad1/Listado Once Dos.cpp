#include <stdio.h>
#include <string.h>

struct{ 
	char nom[30];
	char pac[30];
	int votos;
	
} candidato[4];

int main(){ 
	int i, mayor = 0, aux;
	
	printf("\nNombre candidato: ");
	gets(candidato[0].nom);
		
	printf("\nPacto politico: ");
	gets(candidato[0].pac);
		
	printf("\nCantidad de votos:");
	scanf("%d",&candidato[0].votos);
	
	getchar();
	
	printf("----------------------------\n");
	
	for(i = 1; i < 4; i++){ 
		printf("\nNombre candidato: ");
		gets(candidato[i].nom);
		
		printf("\nPacto politico: ");
		gets(candidato[i].pac);
		
		printf("\nCantidad de votos:");
		scanf("%d",&candidato[i].votos);
		
		getchar();
		
		printf("----------------------------\n");
		
		if(candidato[i].votos > candidato[mayor].votos){
			aux = mayor;
			mayor = i;
			
		}
	}
	
	printf("CANDIDATO VOTOS\n");
	
	printf("%-20s\t%d\n", candidato[mayor].nom, candidato[mayor].votos);
	 
	for(i = 0; i < 4; i++){
		if(i != mayor && i != aux){
			printf("%-20s\t%d\n", candidato[i].nom, candidato[i].votos);
		
		}else if(i != aux){
			printf("%-20s\t%d\n", candidato[aux].nom, candidato[aux].votos);
			
		}
	}
	
	return (0);
} 