#include <stdio.h>

struct{
	int dia;
	int hora;
	int ano;
	
}fecha;

int main (){
	
	printf("Ingrese dia: ");
	scanf("%d", &fecha.dia);
	
	printf("\nIngrese hora: ");
	scanf("%d", &fecha.hora);
	
	printf("\nIngrese a�o: ");
	scanf("%d", &fecha.ano);
	
	return (0);
}
