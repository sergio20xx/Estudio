#include <stdio.h>
#include <windows.h>

int main (){
	int personas, asado, gasto;
	
	printf("Ingrese el gasto total del asado: $");
	scanf("%d", &gasto);
	
	printf("\nIngrese la cantidad de personas que asistiran: ");
	scanf("%d", &personas);
	
	asado = gasto/personas;
	
	printf("\nEl aporte por persona debe de ser: $%d", asado);
	
	return (0);
}
