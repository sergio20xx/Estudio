#include <stdio.h>

int main(){
	int a, b, c;
	float x, y, z;
	
	a=10;
	b=6;
	c=a/b;
	x=10;
	y=6;
	z=x/y;
	
	printf("%d\n", c);
	printf("%f\n", z);
	printf("%f\n", 21/10);
	
	return(0);
}
