#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){ 
	int n, i, cont = 0, mayor = 0, indice, t;
	float porcentaje;

	printf("Generacio de datos (N): ");
	scanf("%d", &n);
	 
	printf("\nIngrese el valor de T: ");
	scanf("%d", &t);
	
	int aux[n];
	
	srand(time(NULL)); 
	
	int temp[n];

	for(i = 0;i < n; i++){
		temp[i] = rand() % 40;
		//Punto c.ii
		if(temp[i] > mayor){
			mayor = temp[i];
			indice = i + 1;
		}
		
		//Punto c.i
		if(temp[i] < 5){
			cont ++;
		}
		
		//Punto c.iii
		if(temp[i] == t){
			aux[i] = i + 1;
			
		}else{
			aux[i] = 0;
			
		}
		
	}
	 
	for(i = 0; i < n; i++){
		printf("%8d", temp[i]);
	
	}
	
	// Punto c.i
	porcentaje = cont * 100 / n;
	
	printf("\nEl procentaje menor a 5 grados es: %.1f\n", porcentaje);
	
	//Punto c.ii
	printf("\nLa temperatura mayor es: %d, en indice %d\n", mayor, indice);
	
	//Punto c.iii
	printf("\nEl valor de T es %d, y los indices son: \n", t);
	
	for(i = 0; i < n; i++){
		if(aux[i] > 0){
			printf("\nIndice: %d", aux[i]);
	
		}
	}
	
	return (0);
} 
