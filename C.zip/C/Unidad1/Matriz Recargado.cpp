#include <stdio.h>

int main (){
	int n, m, cont = 1;
	
	printf("Filas: ");
	scanf("%d", &n);
	
	printf("\nColumnas: ");
	scanf("%d", &m);
	
	int a[n][m];
	
	for(int i = 0; i < m; i++){
		for(int j = 0; j < n; j++){
			a[j][i] = cont++;
		}
	}
	
	for(int i = 0; i < n ; i++){
		for(int j = 0; j < m; j++){
			printf("[%d]", a[i][j]);
			
		}
		printf("\n");
		
	}
	
	return (0);
}
