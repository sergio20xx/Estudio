#include <stdio.h>

int main (){
	int i, j, a=42, matriz[4][5];
	
	/*for(i=0; i<5; i++){
		printf("*");
			if(i==4){
				printf("\n*   *\n");
			}
	}
	for(j=0; j<5; j++){
		printf("*");
	}*/
	
	matriz[0][0]=a;
	matriz[0][1]=a;
	matriz[0][2]=a;
	matriz[0][3]=a;
	matriz[0][4]=a;
	matriz[1][0]=a;
	matriz[1][1]="";
	matriz[1][2]="";
	matriz[1][3]="";
	matriz[1][4]=a;
	matriz[2][0]=a;
	matriz[2][1]=a;
	matriz[2][2]=a;
	matriz[2][3]=a;
	matriz[2][4]=a;
	
	for(i=0; i<5; i++){
		printf("%c", matriz[0][i]);
	}
	printf("\n");
			
	for(i=0; i<5; i++){
		printf("%c", matriz[1][i]);
	}
	printf("\n");
			
	for(i=0; i<5; i++){
		printf("%c", matriz[2][i]);
	}
	
	return(0);
}
