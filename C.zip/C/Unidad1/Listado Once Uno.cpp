#include <stdio.h>

struct { 
	int codigo;
	char nombre[25];
	int num_horas;
	//Punto c).
	char nombre_profesor[25];
	
}asig;
 
int main (){ 
	printf("Codigo de asignatura: ");
	scanf("%d", &asig.codigo);
	
	getchar();
	
	printf("\nNombre de la asignatura: ");
	gets(asig.nombre);
	
	printf("\nNombre del profesor: ");
	gets(asig.nombre_profesor);
 
	printf("\nCantidad de horas a la semana:");
	scanf("%d", &asig.num_horas);
	
	//Punto b).
	printf("\nCodigo: %d, Nombre: %s, Nombre profesor: %s, Horas: %d.", 
	asig.codigo, asig.nombre, asig.nombre_profesor, asig.num_horas);
	
	return (0);
 
}
