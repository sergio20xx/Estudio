#include <stdio.h>

struct{
	int codigo;
	char nombre[50];
	float peso;
	
}producto;

struct{
	float x1, x2, y1, y2;

}recta[3];

int main (){
	
	/*printf("Ingrese codigo: ");
	scanf("%d", &producto);
	
	getchar();
	
	printf("\nIngrese nombre: ");
	gets(producto.nombre);
	
	printf("\nIngrese el peso: ");
	scanf("%f", &producto.peso);
	
	printf("\n%d", producto);
	printf("\n%s", producto.nombre);
	printf("\n%f", producto.peso);*/
	
	for(int i = 0; i < 4; i++){
		printf("\nRecta %d: Ingrese X1: ", i + 1);
		scanf("%f", &recta[i].x1);
	
		printf("\nRecta %d: Ingrese X2: ", i + 1);
		scanf("%f", &recta[i].x2);
	
		printf("\nRecta %d: Ingrese Y1: ", i + 1);
		scanf("%f", &recta[i].y1);
	
		printf("\nRecta %d: Ingrese Y2: ", i + 1);
		scanf("%f", &recta[i].y2);
	
	}
	
	for(int i = 0; i < 4; i++){
		printf("\nRecta %d: Puntos X1: %.1f, Punto X2: %.1f, Punto Y1: %1.f, Punto Y2: %.1f", 
		i + 1, recta[i].x1, recta[i].x2, recta[i].y1, recta[i].y2);

	}
	
	return (0);
}
