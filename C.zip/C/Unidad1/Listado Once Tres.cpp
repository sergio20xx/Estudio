#include <stdio.h>

struct{
	char calle[20];
	int numero;
	char ciudad[20];
	char pais[10];
	
}direccion;

int main (){
	
	printf("Ingrese calle: ");
	gets(direccion.calle);
	
	printf("\nIngrese numero: ");
	scanf("%d", &direccion.numero);
	
	getchar();
	
	printf("\nIngrese ciudad: ");
	gets(direccion.ciudad);
	
	getchar();
	
	printf("\nIngrese pais: ");
	gets(direccion.pais);
	
	return (0);
}
