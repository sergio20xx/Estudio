#include <stdio.h>

int main(){ 
	int dia;
	
	printf("Ingrese un n�mero del d�a: ");
	scanf("%d", &dia);
	
	if(dia == 1){
		printf("31");
	}
	
	if(dia ==2 ){
		printf("28");
	}
	
	if(dia == 3){
		printf("31");
	}
	
	if(dia == 4){
		printf("30");
	}
	
	if(dia == 5){
		printf("31");
	}
	if(dia == 6){
		printf("30");
	}
	
	if(dia == 7){
		printf("31");
	}	
	
	if(dia == 8){
		printf("31");
	}	
	
	if(dia == 9){
		printf("31");
	}	
	
	if(dia == 10){
		printf("31");
	}
	
	if(dia == 11){
		printf("31");
	}
	
	if(dia == 12 || dia > 12){
		printf("31");
	}	
		return (0);
}
