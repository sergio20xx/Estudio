#include <stdio.h>

int main (){
	//int x[2][5], m[4][4], matriz[4][4], i, j;
	
	/*for(i = 0; i < 2; i++){
		for(j = 0; j < 5; j++){
			printf("Dame un valor: ");
			scanf("%d", &x[i][j]);
		}
	}
	
	printf("\nMatriz ingresada:\n\n");
	
	for(i = 0; i < 2; i++){
		for(j = 0; j < 5; j++){
			printf("[%3d] ", x[i][j]);

		}
		printf("\n");
		
	}*/
	
	/*for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			if(i == j){
				m[i][j] = 1;
				
			}else{
				m[i][j] = 0;
			}
		}
		
	}
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			printf("[%3d] ", m[i][j]);

		}
		printf("\n");
		
	}
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			if(i == 0 || i == 3 || j == 0 || j == 3){
				matriz[i][j] = 1;
				
			}else{
				matriz[i][j] = 0;
			}
		}
	}
	
	printf("\n");
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++){
			printf("[%3d] ", matriz[i][j]);

		}
		printf("\n");
		
	}*/
	
	int n, m, cont = 0;
	
	printf("Filas: ");
	scanf("%d", &n);
	
	printf("\nColumnas: ");
	scanf("%d", &m);
	
	int a[n][m];
	
	for(int i = 0; i < n; i++){
		for(int j = 0; j < m; i++){
			a[i][j] = cont ++;
		}
	}
	
	for(int i = 0; i < n ; i++){
		for(int j = 0; j < m; j++){
			printf("[%d]", a[i][j]);
			
		}
		printf("\n");
		
	}
	
	return (0);
}
