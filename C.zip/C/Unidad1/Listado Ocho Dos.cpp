#include <stdio.h>

int main(){ 
	int edad, i, conhom = 0, conmuj = 0, con60 = 0;
	char genero;
 
	for(i = 0; i < 5; i++){ 
		printf("(M: nMasculino o F: Femenino): ");
		scanf("%c",&genero);
	
		printf("\nIndique su edad: ");
		scanf("%d",&edad);
		
		printf("\n");
 
		getchar();
	
		if(genero == 'M' || genero == 'm'){ 
			if(edad > 18){
				conhom++;
				
			}
		}
		
		if(genero == 'F' && genero == 'f'){
			if(edad < 18){
				conmuj++;
				
			}
		}
		
		if(edad >=60){
			con60++;
		}
	}
	
	printf("\nCantidad de hombres mayor de edad: %d\n", conhom);
	printf("\nCantidad de mujeres menores de edad: %d\n", conmuj);
	printf("\nCantidad de personas mayores de 60: %d\n", con60);
	
	return(0);
} 
