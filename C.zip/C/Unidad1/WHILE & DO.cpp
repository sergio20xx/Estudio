#include <stdio.h>

int main (){
	char i = 1, num;
	
	do{
		printf("\n%d", i++);
		
	}while(i < 10);
	
	return (0);
}
