#include <stdio.h>

#define pulgada 25,5

int main(){
	float celcius, fahrenheit, cant_agua, centimetros;
	char grado = 248; 
	
	printf("Ingrese la temperatura (celcius): ");
	scanf("%f", &celcius);
	
	printf("\nIngrese la cantidad de agua precipitada (pulgadas): ");
	scanf("%f", &centimetros);
	
	fahrenheit = 9 / 5 * celcius + 32;
	cant_agua = pulgada * centimetros;
	
	printf("\nLa temperatura (celcius) es: %.1f%cF\n", fahrenheit, grado);
	printf("\nLa cantidad de agua (centimetros): %.1f Cm", cant_agua);
	
	return(0);
}
