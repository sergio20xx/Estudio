#include <stdio.h>

int main(){
	/*int edad;
	
	printf("Ingresa tu edad: ");
	scanf("%d", &edad);
	
	if(edad < 18){
		printf("\nEres menor de edad.");
	}*/
	
	/*int numero;
	char letra;
	
	printf("Ingrese un numero: ");
	scanf("%d", &numero);
	
	if(numero < 0){
		printf("\nEl numero es negativo.\n");
	}
	
	getchar();
	
	printf("\nIngrese una letra: ");
	scanf("%c", &letra);
	
	if(letra == 'o' || letra == 'O'){
		printf("\nLa letra es 'o'.\n");
	}*/
	
	int uno, dos;
	
	printf("Ingrese el primer numero: ");
	scanf("%d", &uno);
	
	printf("\nIngrese el segundo numero: ");
	scanf("%d", &dos);
	
	if(uno%dos == 0){
		printf("\nEs divisible.\n");
	}
	
	printf("\nThe End");
	
	return(0);
}
