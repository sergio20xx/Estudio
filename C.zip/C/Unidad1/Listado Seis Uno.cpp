#include <stdio.h>

int main(){
	int alumnos, bajo, aprobado, aprobado1, reprobado, reprobado1, porcentaje=37;
	
	printf("Ingrese cantidad de alumnos con nota bajo 4,0: ");
	scanf("%d", &bajo);
	
	printf("\nIngrese cantidad de alumnos del curso: ");
	scanf("%d", &alumnos);
	
	aprobado = alumnos - bajo;
	reprobado = alumnos - aprobado;
	
	aprobado1 = aprobado *100 / (alumnos);
	reprobado1 = reprobado * 100 / (alumnos);
	
	printf("\nEl procentaje de aprobados es: %d%c", aprobado1, porcentaje);
	printf("\nEl procentaje de reprobados es: %d%c", reprobado1, porcentaje);
	
	return(0);
}
