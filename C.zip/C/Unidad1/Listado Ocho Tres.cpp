#include <stdio.h>

int main (){
	int n, num, suma = 0, i;
	
	printf("Ingrese valor de N: ");
	scanf("%d", &n);
	
	for(i = 0; i < n; i++){
		printf("\nIngrese valor de Num%d: ", i+1);
		scanf("%d", &num);
		suma = suma + num;
	}
	
	printf("\nLa suma de los numero es: %d", suma);
	
	return (0);
}
