#include <stdio.h>

int main(){
	int cero=0;
	
	printf("%d", cero);
	
	return(0);
}
