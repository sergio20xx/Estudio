#include <stdio.h>

int main(){
	int i=0;
	
	for(int i=0; i<10; i){
		printf("\n%d", i++);
	}
	
	return(0);
}
