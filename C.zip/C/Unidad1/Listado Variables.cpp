#include <stdio.h>

int main(){
	char arroba=64, uno='9', dos='_';
	int x, a=-1;
	float z;
	
	printf("%u\n", a);
	printf("%c\n", arroba);
	printf("%c %c\n", uno, dos);
	
	return(0);
}
