#include <stdio.h>
#define NV 3

int main (){ 
	int n, i;
	float vuelta[NV], menor = 0;
	
	printf("\nTiempo vuelta 1: ");
	scanf("%f",&vuelta[0]);

	for(i = 1; i < NV; i++){
		do{ 
			printf("\nTiempo vuelta %d: ", i + 1);
			scanf("%f",&vuelta[i]);
			
			if(vuelta[1]){
				menor = vuelta[1] - vuelta[0];
				
			}else if((vuelta[i] - vuelta[i-1]) < menor){
				menor = vuelta[i];
				
			}
			
		}while(vuelta[i] <= vuelta[i-1]);
	}
 
	for(i = 0; i < NV; i++){
		printf("%.1f\n", vuelta[i]);

	}
	
	printf("La menor vuelta es: %.1f", menor);
}

