#include <stdio.h>

int main(){
	char a,b;
	a=64;
	b='#';
	printf("%c, [%c]\n", a, b);
	printf("%d, [%d]\n", a, b);
	
	return(0);
}
