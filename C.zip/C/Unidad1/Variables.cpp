#include <stdio.h>

int main(){
	float iva, peso;
	iva=0.19;
	peso=98;
	double velocidad=107.45;
	printf("Iva es %.2f %%\n", iva);
	printf("Peso: %.1f kilos\n", peso);
	printf("%f km\n", velocidad);
	
}
