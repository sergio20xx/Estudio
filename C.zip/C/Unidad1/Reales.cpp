#include <stdio.h>

int main(){
	float x;
	double y;
	x=0.00000000000001;
	y=0.00000000000000001;
	printf("x:%.20f\n", x);
	printf("y:%g\n",y);
	
	return(0);
}
