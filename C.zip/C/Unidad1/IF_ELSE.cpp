#include <stdio.h>

int main(){
	/*float num;
	
	printf("Ingrese un numero: ");
	scanf("%f", &num);
	
	if(num < 1.75){
		printf("\nEs menor a 1.75.\n");
		
	}else{
		printf("\nEs mayor que 1.75.");
	}*/
	
	/*int num;
	
	printf("Ingrese un numero: ");
	scanf("%d", &num);
	
	if(num % 2 == 0 || num == 0){
		printf("\nEs par.");
		
	}else{
		printf("\nNo es par.");
		
	}*/
	
	/*char a;
	
	printf("Ingrese un caracter: ");
	scanf("%c", &a);
	
	if(a >= '0' && a <= '9'){
		printf("\nEs un numero.\n");
		
	}else{
		printf("\nEs un caracter.\n");
	}*/
	
	return(0);
}
