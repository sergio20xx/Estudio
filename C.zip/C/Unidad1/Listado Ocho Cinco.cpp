#include <stdio.h>

int main (){
	int i = 0, n = 0, ;
	
	printf("Ingrese el valor de 'N': ");
	scanf("%d", &n);
	
	for(; i < n; i++){
		printf("\nHola.\n");
		
	}
	
	return (0);
}
