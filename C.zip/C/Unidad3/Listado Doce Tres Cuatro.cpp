#include <stdio.h>

char valida(char n, int d){
	
	
	return ();
}

int main (){
	int n, d;
	
	printf("Ingrese el valor de N: ");
	scanf("%d", &n);
	
	printf("Ingrese el valor de D: ");
	scanf("%d", &d);
	
	printf("El digito %d se encuentra %d en %", d, valida(n, d), n);
	
	return (0);
}
