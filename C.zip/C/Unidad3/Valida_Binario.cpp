#include <stdio.h>

int esbinario(int bin){
	int digito;
	
	while(bin != 0){
		digito = bin % 10;
		
		if(digito != 0 && digito != 1){
			return (0);
		
		}
		bin = bin / 10;
	
	}
	
	return (1);
}

int main (){
	int bin;
	
	printf("Ingrese un numero binario: ");
	scanf("%d", &bin);
	
	if(esbinario(bin)){
		printf("\nEs binario.");
		
	}else{
		printf("\nNo es binario.");
		
	}
	
	return (0);
}
