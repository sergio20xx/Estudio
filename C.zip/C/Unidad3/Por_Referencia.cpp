#include <stdio.h>

void funcr(int *i){
	*i = *i + 1;
	
}

int main (){
	int i = 6;
	
	funcr(&i);
	
	printf("%d", i);
	
	return (0);
}
