#include <stdio.h>
#define N 5

float promedio(float n[N]){
	float suma = 0;
	
	for(int i = 0; i < N; i++){
		suma = suma + n[i];
		
	}
	
	return(suma / N);
}

void mayormenor(float n[N], float *mayor, float *menor){
	
	*mayor = n[0];
	*menor = n[0];
	
	for(int i = 0; i < N; i++){
		if(n[i] < * menor){
			*menor = n[i];
			
		}else if(n[i] > * mayor){
			*mayor = n[i];
			
		}
	}
}

int main (){
	float notas[N], mayor, menor;
	
	for(int i = 0; i < N; i++){
		do{
			printf("\nIngrese nota %d: ", i + 1);
			scanf("%f", &notas[i]);
			
		}while(notas[i] < 1 || notas[i] > 7);
	}
	
	printf("\n[");
	
	for(int i = 0; i < N; i++){
		printf(" %.1f ", notas[i]);
		
	}
	
	printf("]\n");
	printf("\nEl promedio es: %.1f\n", promedio(notas));
	
	mayormenor(notas, &mayor, &menor);
	
	printf("\nEl mayor es: %.1f\n", mayor);
	printf("\nEl menor es: %.1f\n", menor);
	
	return (0);
}
