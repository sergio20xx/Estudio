#define N 5

float promedia(float n[N], int cuantos){
	float suma = 0;
	
	for(int i = 0; i < cuantos; i++){
		suma = suma + n[i];
		
	}
	
	return(suma / cuantos);
}

void mayormenor(float n[N], int cuantos, float *mayor, float *menor){
	
	*mayor = n[0];
	*menor = n[0];
	
	for(int i = 0; i < cuantos; i++){
		if(n[i] < * menor){
			*menor = n[i];
			
		}else if(n[i] > * mayor){
			*mayor = n[i];
			
		}
	}
}

void ordena(float n[N], int cuantos){
	float aux;
	
	for(int i = 0; i < cuantos - 1; i++){
		for(int j = i + 1; j < cuantos; j++){
			if( n[i] > n[j]){
				aux = n[i];
				n[i] = n[j];
				n[j] = aux;
			}
		}
	}
}

float mediana(float n[N], int cuantos){
	float mediana;
	
	if(cuantos % 2 == 0){
		mediana = (n[cuantos / 2] + n[(cuantos / 2) - 1]) / 2;
		
		return(mediana);
		
	}else{
		mediana = n[(cuantos / 2)];
		
		return(mediana);
		
	}
}
