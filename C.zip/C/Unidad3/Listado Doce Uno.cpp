#include <stdio.h>

int mcd(int a, int b){ 
	int r;
	
	while(b != 0){ 
		r = a % b;
		a = b;
		b = r;
		
	}
 
	return (a);
} 

int main (){
	int a, b;
	
	printf("Valor de a: ");
	scanf("%d", &a);
	
	printf("Valor de b: ");
	scanf("%d", &b);
	
	printf("El MCD es: %d", mcd(a, b));
	
	return (0);
}
