#include <stdio.h>

float suma(float a, float b){

	return (a + b);
}

float cuadrado(float a){

	return (a * a);
}

float div_real(float a, float b){
	
	return (a / b);
}

float promedio(float a, float b, float c){
	float prom;
	
	prom = a * (0.25) + b * (0.35) + c * (0.40);
	
	return (prom);
}

int main (){
	//Funci�n: Suma().
	/*float a, b, resp;
	
	printf("Ingresar a: ");
	scanf("%f", &a);
	
	printf("Ingresar b: ");
	scanf("%f", &b);
	
	resp = suma(a, b);
	
	printf("La suma es: %.1f", resp);*/
	
	//Funci�n: cuadrado().
	/*float a, b;
	
	printf("Ingresar a: ");
	scanf("%f", &a);
	
	printf("El cuadrado de a es: %.1f", cuadrado(a));*/
	
	//Funci�n: div_real().
	/*float a, b;
	
	printf("Ingresar a: ");
	scanf("%f", &a);
	
	printf("Ingresar b: ");
	scanf("%f", &b);
	
	printf("La division de a es: %.1f", div_real(a, b));*/
	
	//Funci�n: promedio().
	float a, b, c;
	
	printf("Ingresar a: ");
	scanf("%f", &a);
	
	printf("\nIngresar b: ");
	scanf("%f", &b);
	
	printf("\nIngresar b: ");
	scanf("%f", &c);
	
	printf("\nEl promedio es: %.1f", promedio(a, b, c));
	
	return (0);
}
