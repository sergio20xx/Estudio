#include <stdio.h>

int valida(int n){
	if(n > 999 && n <= 9999){
		return (1);
		
	}else{
		return (0);
		
	}
}

int main (){
	int n;
	
	printf("Ingrese valor de N: ");
	scanf("%d", &n);
	
	if(valida(n)){
		printf("\nEs un entero de cuatro digitos.");
		
	}else{
		printf("\nNo es un entero de cuatro digitos.");
		
	}
	
	return (0);
}
