#include <stdio.h>

int primo(int numero){
	int contador = 0;
	
	for(int i = 1; i < numero; i++){
		if(numero % i == 0){
			contador ++;
			
		}else if(contador == 1){
			return (1);
			
		}else{
			return (0);
		
		}
	}
}

void busca_primo(int n){
	int contador = 0, i = 2;
	
	while(contador != n){
		if(primo(i)){
			contador++;
			
			printf("%4d", i);
		
		}
		i++;
		
	}
}

int main (){
	int n;
	
	printf("Valor de N: ");
	scanf("%d", &n);
	
	busca_primo(n);
	
	return (0);
}
