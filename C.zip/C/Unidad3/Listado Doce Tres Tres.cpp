#include <stdio.h>

int valida(int n, char *resultado){
	if(n > 0){
		*resultado = 'P';
		
	}else if(n <= 0){
		*resultado = 'N';
		
	}
	
	return (0);
}

int main (){
	int n;
	char resultado;
	
	printf("Ingrese el valor de N: ");
	scanf("%d", &n);
	
	valida(n, &resultado);
	
	printf("\n%c", resultado);
	
	return (0);
}
