#include <stdio.h>

int promedio(int a, int b, int c){ 
	int suma;
	
	suma = (a + b + c);
	
	return (suma / 3);
} 

int main (){
	int a, b, c;
	
	printf("Ingrese a: ");
	scanf("%d", &a);
	
	printf("\nIngrese b: ");
	scanf("%d", &b);
	
	printf("\nIngrese c: ");
	scanf("%d", &c);
	
	printf("\nEl promedio es: %d", promedio(a, b, c));
	
	return (0);
}
