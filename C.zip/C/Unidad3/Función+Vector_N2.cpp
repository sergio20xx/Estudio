#include <stdio.h>
#include "vector2.h"

#define N 5

int main (){
	float notas[N], mayor, menor; 
	int cuantos;
	
	printf("\nIngrese cuantos: ");
	scanf("%d", &cuantos);
	
	for(int i = 0; i < cuantos; i++){
		do{
			printf("\nIngrese nota %d: ", i + 1);
			scanf("%f", &notas[i]);
			
		}while(notas[i] < 1 && notas[i] > 7);
	}
	
	ordena(notas, cuantos);
	
	printf("\n[");
	
	for(int i = 0; i < cuantos; i++){
		printf(" %.1f ", notas[i]);
		
	}
	
	printf("]\n");
	printf("\nEl promedio es: %.1f\n", promedia(notas, cuantos));
	
	mayormenor(notas, cuantos, &mayor, &menor);
	
	printf("\nEl mayor es: %.1f", mayor);
	printf("\nEl menor es: %.1f", menor);
	
	printf("\nLa mediana es: %.1f", mediana(notas, cuantos));
	
	return (0);
}
