#include <stdio.h>

int sumatoria(int n){ 
	int i, s = 0;
	
	for(i = 1; i <= n; i++){
		s = s + i;
		
	}

	return(s);
}

int main (){
	int n;
	
	printf("Valor de N: ");
	scanf("%d", &n);
	
	printf("La sumatoria es: %d", sumatoria(n));
	
	return (0);
}
