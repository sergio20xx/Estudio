#include <stdio.h>

typedef struct x{
	char nombre[30];
	int base;
	float liquido;
	
}nomina;

void imprime_tabla(nomina a[], int n){
	printf("\nNOMBRE               SUELDO\n");
	
	for(int i = 0; i < n ; i++){
		printf("%-20s %6d\n", a[i].nombre, a[i].base);
	}
}

int total(nomina a[], int n){
	int suma = 0;
	
	for(int i = 0; i < n; i++){
		suma = suma + a[i].base;
		
	}
	
	return (suma);
}

void liquido(nomina a[], int n){
	int aux = 0;
	
	for(int i = 0; i < n; i++){
		a[i].liquido = a[i].base + a[i].base * 0.25; 
	}
}

int main (){
	nomina tabla[5];
	
	for(int i = 0; i < 5 ; i++){
		printf("\nNombre: ");
		gets(tabla[i].nombre);
		
		printf("Sueldo base: ");
		scanf("%d", &tabla[i].base);
		
		getchar();
	}
	
	imprime_tabla(tabla, 5);
	
	printf("\nEl gasto total en remuneraciones es: $%d", total(tabla, 5));
	
	printf("\n");
	
	liquido(tabla, 5);
	
	for(int i = 0; i < 5; i++){
		printf("\nEl sueldo liquido para %s es: $%d", tabla[i].nombre, tabla[i].liquido);
		
	}
	
	return (0);
}
