struct{
	char nombre[30];
	int base;
	
}nomina[5];