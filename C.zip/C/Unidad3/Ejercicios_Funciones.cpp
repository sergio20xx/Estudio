#include <stdio.h>

int mayor (int a, int b, int c){
	int mayor;
	
	mayor = a;
	
	if(b > a && b > c){
		mayor = b;
		
	}else if(c > a && c > b){
		mayor = c;
		
	}
	
	return (mayor);
}

int resto (int a, int b){
	
	while(a >= b){
		a = a - b;
	}
	
	return (a);
}

int main (){
	//Funci�n: mayor().
	/*int a, b, c;
	
	printf("Valores de a, b, c: ");
	scanf("%d %d %d", &a, &b, &c);
	
	printf("\nEl mayor es: %d", mayor(a, b, c));*/
	
	int a, b;
	
	printf("Valor de a, b: ");
	scanf("%d %d", &a, &b);
	
	printf("El resto es: %d", resto(a, b));

	return (0);
}
