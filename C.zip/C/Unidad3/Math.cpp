#include <stdio.h>
#include <math.h>

int main (){
	//Calcular pit�goras.
	/*float a, b ,c;
	
	printf("Ingrese valor de a: ");
	scanf("%f", &a);
	
	printf("\nIngrese valor de b: ");
	scanf("%f", &b);
	
	c = sqrt(pow(a, 2) + pow(b, 2));
	
	printf("El valor de c es: %.1f", c);*/
	
	//Calcular numero de bits para cada n�mero.
	int decimal, numbit;
	
	printf("Ingrese valor del decimal: ");
	scanf("%d", &decimal);
	
	numbit = floor(log(decimal) / log(2)) + 1;
	
	printf("\nEl numero de bits: %d", numbit);
	
	return (0);
}
