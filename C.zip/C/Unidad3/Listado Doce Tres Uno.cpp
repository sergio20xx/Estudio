#include <stdio.h>
#include <math.h>

float hipotenusa(float adyacente, float opuesto){
	float hipotenusa;
	
	hipotenusa = pow(adyacente, 2) + pow(opuesto, 2);
	
	return (sqrt(hipotenusa));
}

int main (){
	float adyacente, opuesto;
	
	printf("Ingrese cateto adyacente: ");
	scanf("%f", &adyacente);
	
	printf("Ingrese cateto opuesto: ");
	scanf("%f", &opuesto);
	
	printf("El valor de la hipotenusa es: %.1f", hipotenusa(adyacente, opuesto));
	
	return (0);
}
