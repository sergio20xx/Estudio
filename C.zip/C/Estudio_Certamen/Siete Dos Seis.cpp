#include <stdio.h>

int main (){
	int num;
	
	printf("Ingrese un numero: ");
	scanf("%d", &num);
	
	if(num >= 0){
		printf("\nEs positivo.");
		
		if(num % 2 == 0 || num == 0){
			printf("\nEs par.");
			
		}else{
			printf("\nEs impar.");
		
		}
		
	}else{
		printf("\nNo es positivo.");
		
	}
	
	return (0);
}
