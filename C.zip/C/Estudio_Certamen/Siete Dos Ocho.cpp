#include <stdio.h>

int main (){
	int edad;
	
	printf("Ingrese edad: ");
	scanf("%d", &edad);
	
	if(edad < 18){
		printf
	}
	
	if(edad >= 18){
		printf("Es mayor de edad.");
	}
	
	return (0);
}
