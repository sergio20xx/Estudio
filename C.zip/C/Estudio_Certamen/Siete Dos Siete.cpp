#include <stdio.h>

int main (){
	int a, b, c, mayor, menor;	
	
	printf("\nIngrese a: ");
	scanf("%d", &a);
	
	printf("\nIngrese b: ");
	scanf("%d", &b);
	
	printf("\nIngrese c: ");
	scanf("%d", &c);
	
	if(a < b && a < c){
		menor = a;
		
	}else{
		mayor = a;
		
	} // A menor.
	
	if(b < a && b < c){
		menor = b;
		
	}else{
		mayor = b;
		
	}
	
	if(c < a && c < b){
		menor = c;
		
	}else{
		mayor = c;
		
	}
	
	if(a > mayor){
		mayor = a;
		
	}
	
	if(b > mayor){
		mayor = b;
		
	}
	
	printf("\nEl menor es: %d", menor);
	printf("\nEl mayor es: %d", mayor);
	
	return (0);
}	
