#include <stdio.h>

int main (){
	int a, b;
	
	printf("Ingresar A: ");
	scanf("%d", &a);
	
	printf("Ingresar B: ");
	scanf("%d", &b);
	
	if(a == b){
		printf("\nA es igual a B.");
		
		if(a < b){
			printf("\nA es menor que B.");
			
		}	
		
	}else{
		printf("\nA es distinto de B.");
		
		if(a < b){
			printf("\nA es menor que B.");
			
		}else{
			printf("\nA es mayor que B.");
		}
	}
	
	return (0);
}
