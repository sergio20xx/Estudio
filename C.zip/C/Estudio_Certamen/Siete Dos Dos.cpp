#include <stdio.h>

int main (){
	int a, b;
	
	printf("Ingrese a: ");
	scanf("%d", &a);
	
	printf("\nIngrese b: ");
	scanf("%d", &b);
	
	if(a % b == 0){
		printf("\nEs multiplo.");
		
	}else{
		printf("\nNo es multiplo.");
	}
	
	return (0);
}
