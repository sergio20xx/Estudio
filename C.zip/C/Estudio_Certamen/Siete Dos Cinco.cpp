#include <stdio.h>

int main (){
	int num;
	
	printf("\nIngrese un numero: ");
	scanf("%d", &num);
	
	if(num % 5 == 0 && num % 10 != 0){
		printf("\nEs divisible por cinco solamente.");
		
	}else{
		printf("\nNo es solamente divisible por 5.");
		
	}
	
	return (0);
}
