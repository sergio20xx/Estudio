#include <stdio.h>

int main (){
	float num, absoluto;
	
	printf("Ingrese un numero: ");
	scanf("%f", &num);
	
	if(num < 0){
		absoluto = num * -1;
		
	}else{
		absoluto = num;
		
	}
	
	printf("%f", absoluto);
	
	return (0);
}
