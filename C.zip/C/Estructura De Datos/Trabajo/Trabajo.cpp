#include <stdio.h>
#include <stdlib.h>
#define N 3
#define FALSE 0
#define TRUE 1

typedef struct nodo{
	int indice;
	int m[N][N];
	int regla;
	struct nodo *siguiente;
	struct nodo *anterior;
	
} *nodoptr;

void imprimir_lista(nodoptr lista){
	int cont = 0;
	nodoptr aux = lista;
	
	do{
		if(cont == 0){
			printf("NODO INICIAL\n");
			printf("------------\n\n");
			
			lista -> indice = 0;
			
		}else{
			lista -> indice = cont;
			
			printf("\nNODO: %d\n", lista -> indice);
			printf("-------\n");
			
			aux = aux -> siguiente;
			
			printf("\n\t\tRegla: R%d\n\n", aux -> regla);
			
		}
		
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				printf("\t[%d]", aux -> m[i][j]);
				
			}
			
			printf("\n");
			
		}
		
		cont ++;
		
	}while(aux -> siguiente != NULL);
}

int valida_repeticion(nodoptr nuevo, nodoptr inicial){
	int cont;
	nodoptr lista = inicial -> siguiente;
	
	do{
		cont = 0;
		
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++){
				if(nuevo -> m[i][j] == lista -> m[i][j]){
					cont++;
					
					printf("\n%d\n", cont);
					
				}
			}	
		}
		
		lista = lista -> siguiente;
		
	}while(lista -> siguiente != NULL || cont != 9);
	
	if(cont == 9){		
		return (TRUE);
		
	}else{
		return (FALSE);
		
	}
}

nodoptr generar_nodo(nodoptr lista, nodoptr inicial, int regla){
	int a, b, i, j;
	nodoptr nuevo;
	
	nuevo = (nodoptr )malloc(sizeof(struct nodo));
	
	nuevo -> siguiente = NULL;
	
	nuevo -> regla = regla;

	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			if(lista -> m[i][j] != 0){
				nuevo -> m[i][j] = lista -> m[i][j];
				
			}else{
				if(nuevo -> regla == 1){
					a = i - 1;
					b = j;
					
					nuevo -> m[i][j] = lista -> m[a][b];
					
				}
				
				if(nuevo -> regla == 2){
					a = i + 1;
					b = j;
					
					nuevo -> m[i][j] = lista -> m[a][b];
					
				}
				
				if(nuevo -> regla == 3){
					a = i;
					b = j - 1;
					
					nuevo -> m[i][j] = lista -> m[a][b];
					
				}
				
				if(nuevo -> regla == 4){
					a = i;
					b = j + 1;
					
					nuevo -> m[i][j] = lista -> m[a][b];
					
				}
				
			}
		}
	}
	
	printf("\n%d %d\n", a, b);
	
	nuevo -> m[a][b] = 0;
	
	if(a < 0 || a > 2 || b < 0 || b > 2){
		generar_nodo(lista, inicial, regla + 1);
		
	}
	
	return (nuevo);
}

int valida_solucion(nodoptr nuevo){
	int final[N][N], cont = 0, respuesta = FALSE;
	
	final[0][0] = 1;
	final[0][1] = 2;
	final[0][2] = 3;
	final[1][0] = 4;
	final[1][1] = 5;
	final[1][2] = 6;
	final[2][0] = 7;
	final[2][1] = 8;
	final[2][2] = 0;
	
	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			if(nuevo -> m[i][j] == final[i][j]){
				cont++;
				
			}
		}
	}
	
	if(cont == 9){
		respuesta = TRUE;
		
	}
	
	return (respuesta);
}

int main (){
	int i, regla = 1;
	nodoptr inicial, aux1, aux2;
	
	inicial = (nodoptr )malloc(sizeof(struct nodo));
	
	inicial -> m[0][0] = 1;
	inicial -> m[0][1] = 2;
	inicial -> m[0][2] = 3;
	inicial -> m[1][0] = 4;
	inicial -> m[1][1] = 5;
	inicial -> m[1][2] = 6;
	inicial -> m[2][0] = 7;
	inicial -> m[2][1] = 0;
	inicial -> m[2][2] = 8;
	
	inicial -> anterior = NULL;
	
	inicial -> regla = 0;
	
	aux1 = inicial;
	
	for(i = 0; i < 4; i++){
		aux2 = generar_nodo(aux1, inicial, regla);
		
		aux2 -> anterior = aux1;
		
		aux1 -> siguiente = aux2;
		
		aux1 = aux2;
		
		if(valida_solucion(aux1) == TRUE){
			imprimir_lista(inicial);
			
			printf("\n\t\tSOLUCION FINAL ENCONTRADA\n");
			printf("\nEs el nodo indice: %d", aux1 -> indice);
			
			return (0);
		}
	}
	
	printf("\n\t\tSOLUCION FINAL NO ENCONTRADA\n");
	
	imprimir_lista(inicial);
	
	return (0);
}
