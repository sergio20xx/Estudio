#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define N 2

struct stock{
	char nombre[20];
	int precio;
	int cantidad;
	
};

void menu(int *opcion){
	
	system("cls");
	
	printf("\n	MENU\n");
	printf("	----\n");
	printf("1.- Ingresar producto.");
	printf("\n2.- Buscar producto.");
	printf("\n3.- Modificar producto.");
	printf("\n4.- Listar productos.\n");
	printf("\n5.- Salir.\n");
	
	printf("\nIngrese opcion: ");
	scanf("%d", &*opcion);
	
}

int main (){
	int opcion = 0, indice = 0, id = 0, verificar = 0;
	char producto[20], valida = 0;
	struct stock almacen[N];
	
	do{
		menu(&opcion);
		
		switch(opcion){
			case 1:
				getchar();
				
				printf("\nIngresar\n");
				printf("--------\n");
				
				printf("\nIngrese el nombre del producto %d: ", indice + 1);
				gets(almacen[indice].nombre);
		
				printf("\nIngrese el precio del producto %d: $", indice + 1);
				scanf("%d", &almacen[indice].precio);
		
				printf("\nIngrese la cantidad del producto %d: ", indice + 1);
				scanf("%d", &almacen[indice].cantidad);
				
				indice++;
				
				verificar = 1;
				
				getchar();
				
				break;
				
			case 2:
				
				printf("\nBUSCAR\n");
				printf("------\n");
				
				if(verificar == 1){
					fflush(stdin);
					
					printf("\nProducto a buscar?: ");
					gets(producto);
				
					for(int i = 0; i < indice; i++){
						if(strcmp(producto, almacen[i].nombre) == 0){
							printf("\nProducto encontrado.\n");
							valida = 0;
							id = i;
		
						}else{
							valida = 1;
		
						}
					}
				
					if(valida == 1){
						printf("\nProducto no encontrado.\n");
			
					}
					
				}else{
					printf("\nError: primero ingrese productos.\n");
					
				}
				
				printf("\n");
				
				system("pause");
				
				break;
			
			case 3: 
				
				if(verificar == 1){
				
					getchar();
					
					printf("\nMODIFICAR\n");
					printf("---------\n");
				
					printf("\nNombre del producto (Nombre: %s): ", almacen[id].nombre);
					gets(almacen[id].nombre);
		
					printf("\nPrecio del producto (Precio: $%d): $", almacen[id].precio);
					scanf("%d", &almacen[id].precio);
		
					printf("\nCantidad del producto (Unidades: %d): ", almacen[id].cantidad);
					scanf("%d", &almacen[id].cantidad);
				
					getchar();
					
				}else{
					printf("\nError: primero ingrese productos.\n");
					
				}
				
				printf("\n");
				
				system("pause");
				
				break;
				
			case 4:
				
				if(verificar == 1){
					printf("\nLISTADO DE PRODUCTOS");
					printf("\n--------------------\n");
					printf("\n   ID          Nombre          Precio          Cantidad");
					printf("\n   --          ------          ------          --------");
					
					for(int i = 0; i < indice; i++){
						printf("\n   %-3d          %-10s   %-10d  %-10d", 
						i + 1, almacen[i].nombre, almacen[i].precio, almacen[i].cantidad);
					
					}
					
					printf("\n");
					
				}else{
					printf("\nError: primero ingrese productos.\n");
					
				}
				
				printf("\n");
				
				system("pause");
				
				break;
				
			case 5:
	
				break;
				
			default:
				printf("\nError, ingrese opcion correcta(1/2/3).\n");
				
				system("pause");
				
				break;
		}
		
	}while(opcion != 0 && opcion != 5);
	
	return (0);
}
