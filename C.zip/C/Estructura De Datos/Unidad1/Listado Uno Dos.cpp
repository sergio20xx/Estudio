#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#define N 6

struct alumno{
	char nombre[20];
	float nota;
	
};

void menu(int opcion){
	system("cls");
	
	printf("MENU");
	printf("\n----\n");
	
	printf("\n1.- Buscar alumno.");
	printf("\n2.- Modificar nota.");
	printf("\n3.- Calcular media de todas las notas.");
	printf("\n4.- Calcular media de las 5 menores notas.");
	printf("\n5.- Alumno con mejores notas.");
	printf("\n6.- Alumno con peores notas.");
	printf("\n7.- Salir.\n");
	
}

void buscar(char nombre[20], alumno curso[N], int *indice){
	
	*indice = -1;
					
	for(int i = 0; i < N; i++){
		if(strcmp(curso[i].nombre, nombre) == 0){
			*indice = i;
							
			break;
							
		}
	}
					
	if(*indice == -1){
		printf("\nNo encontrado.\n");
					
	}else{
		printf("\nEncontrado, y la nota es: %.1f\n", curso[*indice].nota);
					
	}
}

int main (){
	alumno curso[N];
	int opcion, indice;
	float media, menor[5], aux[5], suma = 0;
	char nombre[20];
	
	for(int i = 0; i < N; i++){
		printf("INGRESAR ALUMNO");
		printf("\n---------------\n");
		
		printf("\nIngrese nombre de alumno %d: ", i + 1);
		gets(curso[i].nombre);
		
		printf("\nIngrese nota de alumno %d: ", i + 1);
		scanf("%f", &curso[i].nota);
		
		getchar();
		
		system("cls");
	
	}
	
	do{
		menu(opcion);
		
		printf("\nIngrese opcion: ");
		scanf("%d", &opcion);
		
		if(opcion < 1 || opcion > 7){
			printf("\nError, ingrese opcion valida.\n");

			system("pause");
			
		}else{
			switch(opcion){
		
				case 1:
					
					getchar();
					
					printf("\nBUSCAR");
					printf("\n------\n");
					
					printf("\nNombre a buscar: ");
					gets(nombre);
					
					buscar(nombre, curso, &indice);
					
					system("pause");
					
					break;
					
				case 2:
					
					getchar();
					
					printf("\nMODIFICAR");
					printf("\n---------\n");
					
					printf("\nNombre a modifcar: ");
					gets(nombre);
					
					buscar(nombre, curso, &indice);
					
					if(indice != -1){
						fflush(stdin);
						
						printf("\nAlumno nombre (nombre: %s): ", curso[indice].nombre);
						gets(curso[indice].nombre);
						
						printf("\nAlumno nota (nota: %.1f): ", curso[indice].nota);
						scanf("%f", &curso[indice].nota);
						
					}
					
					printf("\n");
					
					system("pause");
					
					break;
					
				case 3:
					
					getchar();
					
					printf("\nMEDIA DEL CURSO");
					printf("\n---------------\n");
					
					media = 0;
					
					for(int i = 0; i < N; i++){
						media = media + curso[i].nota;
						
					}
					
					printf("\nLa media del curso es: %.1f\n\n", media / N);
					
					system("pause");
					
					break;
					
				case 4:
					
					printf("\nCALCULAR MEDIA 5 PEORES NOTAS");
					printf("\n-----------------------------\n");
					
					for(int j = 0; j < 5; j++){
						
						aux[j] = curso[j].nota;
						menor[j] = j;
						
						for(int i = 0; i < N; i++){
							if(aux[j] < curso[i].nota){
								for(int k = j - 1; k > -1; k--){
									if(menor[j] != menor[k]){
										menor[j] = i;
										
									}
								}
							}
						}
					}
					
					for(int i = 0; i < N; i++){
						suma =  suma + curso.[menor[i]].nota;
					
					}
					
					printf("\nEl promedio de las 5 peores notas es: %.1f", suma / 5);
					
					system("pause");
					
					break;
					
				case 5:
					break;
					
				case 6:
					break;
					
				case 7:
					
					break;
			}
		}
		
	}while(opcion != 7);
	
	printf("\nSALIENDO, BYE...");
	
	return (0);
}
