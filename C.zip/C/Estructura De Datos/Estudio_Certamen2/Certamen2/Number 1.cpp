#include <stdio.h>
#include <stdlib.h>

typedef struct nodoLista{
	int info;
	struct nodoLista *sig;

}*LISTA;

LISTA sumar_uno(LISTA lista){
	
	LISTA aux;
	
	aux = lista;
	
	while(aux -> sig != NULL){
		aux -> info = aux -> info + 1;
		
		aux = aux -> sig;
		
	}
	
	aux -> info = aux -> info + 1;
}

int main (){
	LISTA L, lista = NULL, aux, p;
	int elemento;
	
	for(int i = 0; i < 5; i++){
		L = (LISTA )malloc(sizeof(struct nodoLista));
		
		printf("Ingrese dato %d: ", i + 1);
		scanf("%d", &L -> info);
		
		L -> sig = NULL;
		
		if(lista == NULL){
			lista = L;
			
		}else{
			aux = lista;
			
			while(aux -> sig != NULL){
				aux = aux -> sig;
			}
			
			aux -> sig = L;
		}
	}
	
	aux = lista;
	
	while(aux -> sig != NULL){
		printf("\t%d", aux -> info);
		
		aux = aux -> sig;
		
	}
	
	printf("\t%d", aux -> info);
	
	/*p = lista;
	
	sumar_uno(p);
	
	printf("\nLISTA SUMADA\n\n");
	
	while(p -> sig != NULL){
		printf("\t%d", p -> info);
		
		p = p -> sig;
		
	}
	
	printf("\t%d", p -> info);*/
	
	printf("\nElemento a eliminar: ");
	scanf("%d", &elemento);
	
	aux = lista;
	
	do{
		p = aux;
		
		aux = aux -> sig;
		
		if(aux -> info == elemento){
			p -> sig = aux -> sig;
			
		}
		
	}while(aux -> sig != NULL);
	
	aux = lista;
	
	printf("\nLISTA CON ELEMENTO ELIMINADO:\n\n");
	
	while(aux -> sig != NULL){
		printf("\t%d", aux -> info);
		
		aux = aux -> sig;
		
	}
	
	printf("\t%d", aux -> info);
	
	return (0);
}
