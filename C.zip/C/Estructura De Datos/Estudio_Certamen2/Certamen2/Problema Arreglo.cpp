#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (){
	int arreglo[5], *puntero;
	
	srand(time(NULL));
	
	for(int i = 0; i < 5; i++){
		arreglo[i] = rand() % 50;
	
	}
	
	puntero = arreglo;
	
	for(int i = 0; i < 5; i++){
		printf("%d\t", *puntero++);
		
	}
	
	return (0);
}
