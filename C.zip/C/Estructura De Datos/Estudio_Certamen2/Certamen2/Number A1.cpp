#include <stdio.h>
#include <strings.h>

int main (){
	char palabra[20];
	int cantidad, i , j, total = 0, sum1 = 0, sum2 = 0;
	
	printf("Ingrese una palabra: ");
	gets(palabra);
	
	cantidad = strlen(palabra);
	
	j = cantidad - 1;
	
	for(i = 0; i < cantidad / 2; i++){
		if(palabra[i] == palabra[j]){
			sum1++;
		
		}else{
			sum2++;
	
		}
		
		j--;
		
	}
	
	if(sum2 == 0){
		total = 1;
		
	}
	
	if(total == 1){
		printf("\nEs palindrome.");
		
	}else{
		printf("\nNo es palindrome.");
	}		
	
	return (0);
}
