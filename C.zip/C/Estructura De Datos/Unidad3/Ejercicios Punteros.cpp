#include <stdio.h>

void pedir_guardar(int *x);

int main (){
	int a;
	
	pedir_guardar(&a);
	
	printf("%d", a);
	
	return (0);
}

void pedir_guardar(int *x){
	printf("\nDame un numero: ");
	scanf("%d", x);
	
}
