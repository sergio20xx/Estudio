#include <stdio.h>
#include <stdlib.h>

int main (){
	int x, *p;
	
	printf("Ingrese valor de x: ");
	scanf("%d", &x);
	
	p = &x;
	
	printf("\nEl valor de x es: %d\n", *p);
	
	printf("\nDireccion de p: %p", p);
	
	return (0);
}
