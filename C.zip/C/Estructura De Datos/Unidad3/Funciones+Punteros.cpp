#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <time.h>

#define n 5

int main (){
	//Punto a).
	
	/*char a[20], *p;
	int cont = 0, n;
	
	printf("Ingrese una palabra: ");
	gets(a);
	
	p = &a[0];
	
	n = strlen(a);
	
	for(int i = 0; i < n; i++){
		if(*p == 'a' || *p == 'e' || *p == 'i' || *p == 'o' || *p == 'u'){
			cont ++;
			
		}	
		
		*p++;
		
	}
	
	printf("\nLa cantidad de vocales es: %d", cont);*/
	
	//Punto b).
	
	int a[n], aux;
	
	//Ciclo Burbuja.
	
	/*srand(time(NULL));
	
	printf("Vector antes de ordenar:\n\n");
	
	for(int i = 0; i < n; i++){
		a[i] = rand() % 10 + 1;
		
		printf("\t[%d]", a[i]);
	
	}
	
	for(int i = 0; i < n; i++){ 
		for(int j = 0; j < n - i; j++){ 
			if(a[j] >= a[j + 1]){ 
				aux = a[j]; 
				a[j] = a[j + 1]; 
				a[j + 1] = aux; 
				
			} 
		} 
	} 
	
	printf("\n\nVector despues de ordenar:\n\n");
	
	for(int i = 0; i < n; i++){
		printf("\t[%d]", a[i]);
		
	}*/
	
	srand(time(NULL));
	
	printf("Vector antes de ordenar:\n\n");
	
	for(int i = 0; i < n; i++){
		a[i] = rand() % 10 + 1;
		
		printf("\t[%d]", a[i]);
	
	}
	
	for(int i = 0; i < n; i++){ 
		if(i < n - 1){
			if(a[i] < a[i + 1]){ 
				aux = a[i]; 
				a[i] = a[i + 1]; 
				a[i + 1] = aux;
			
			}
		}
	} 
	
	printf("\n\nVector despues de ordenar:\n\n");
	
	for(int i = 0; i < n; i++){
		printf("\t[%d]", a[i]);
		
	}
	
	return (0);
}
