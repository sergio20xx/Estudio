#include <stdio.h>

int main (){
	int x = 23, y, *p, *q;
	
	p = &x;
	y = *p;
	
	printf("\n%d", y);
	
	q = p;
	
	printf("\n%d", *q);
	
	printf("\nDireccion hexadecimal de p: %p", &p);
	
	printf("\nDireccion hexadecimal que guarda p: %p", p);
	
	printf("\nDireccion hexadecimal de x: %p", &x);
	
	return (0);
}
