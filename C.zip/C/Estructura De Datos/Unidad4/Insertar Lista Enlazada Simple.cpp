#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
	int dato;
	struct nodo *siguiente;
	
} *nodoptr;

int main (){
	nodoptr aux, nuevo, lista = NULL;
	
	for(int i = 0; i < 5; i++){
		
		nuevo = (nodoptr )malloc(sizeof(struct nodo));
		
		printf("\nIngrese primer elemento: ");
		scanf("%d", &nuevo -> dato);
		
		nuevo -> siguiente = NULL;
		
		if(i == 0){
			lista = nuevo;
	
		}else{
			nuevo -> siguiente = lista;
		
			lista = nuevo;
		
		}
	}
	
	aux = lista;
	
	for(int i = 0; i < 5; i++){
		printf("\t%d", aux -> dato);
		
		aux = aux -> siguiente;
		
	}
	
	return (0);
}
