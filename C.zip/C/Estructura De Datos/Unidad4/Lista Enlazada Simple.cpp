#include <stdio.h>
#include <stdlib.h>

typedef struct nodo{
	int dato;
	struct nodo *siguiente;
	
} *nodoptr;

int main (){
	nodoptr aux, lista = NULL, r;
	
	for(int i = 0; i < 5; i++){
		aux = (nodoptr )malloc(sizeof(struct nodo));
		
		printf("\nIngrese dato %d: ", i + 1);
		scanf("%d", &aux -> dato);
	
		aux -> siguiente = lista;
	
		lista = aux;
		
	}
	
	printf("\nDatos de la lista:\n\n");
	
	r = lista;
	
	for(int i = 0; i < 5; i++){
		printf("\t%d", r -> dato);
		
		r = r -> siguiente;
	}
	
	return (0);
}
