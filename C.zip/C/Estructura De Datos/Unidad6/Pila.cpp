#include <stdio.h>
#include <stdlib.h>
#define MAX 5
#define FALSE 0
#define TRUE 1

int pila_llena(int tope){
	int respuesta = FALSE;
	
	if(tope == MAX - 1){
		respuesta = TRUE;
		printf("\nPila llena.\n");
		
	}
	
	return (respuesta);
}

void push(int pila[], int dato, int *tope){
	
	if(pila_llena(*tope) == FALSE){
		*tope = *tope + 1;
	
		pila[*tope] = dato;
	
	}
}

int pila_vacia(int tope){
	int respuesta = FALSE;
	
	if(tope == -1){
		respuesta = TRUE;
		
		printf("\nPila vacia.");
	
	}
	
	return (respuesta);
}

void pop(int pila[], int *tope){
	
	if(pila_vacia(*tope) == FALSE){
		*tope = *tope - 1;
		
	}else{
		printf("\nError,imposible hacer pop.\n");
		
	}
}

void mostrar(int pila[], int tope){
	
	printf("\nPILA:");
	printf("\nTOPE: %d\n", tope);
	
	for(int i = tope; i >= 0; i--){
		printf("\n\t| %d |", pila[i]);
		printf("\n\t+----+");
		
	}
}

void menu(){
	system("cls");
	
	printf("\nMENU");
	printf("\n----\n");
	printf("\n1.- Push.");
	printf("\n2.- Pop.");
	printf("\n3.- Salir.");
	
}

int main (){
	int pila[MAX], tope = -1, opcion, dato;
	
	system("color B2");
	
	do{
		menu();
		
		printf("\n\nIngrese opcion: ");
		scanf("%d", &opcion);
		
		switch(opcion){
			
			case 1:
				
				printf("\nDato a ingresar: ");
				scanf("%d", &dato);
				
				push(pila, dato, &tope);
				mostrar(pila, tope);
				
				printf("\n\n");
				
				system("pause");
				
				break;
			
			case 2:
				
				pop(pila, &tope);
				mostrar(pila, tope);
				
				printf("\n\n");
				
				system("pause");
				
				break;
				
			case 3:
				
				system("cls");
				
				printf("SALIENDO.");
				
				break;
		}
		
	}while(opcion != 3);
	
	return (0);
}
