#include <stdio.h>
#include <stdlib.h>
#define MAX 5
#define TRUE 1
#define FALSE 0

int fila_vacia(int frente, int final){
	int respuesta = FALSE;
	
	if(frente == 0 && final == -1){
		respuesta = TRUE;
		
	}
	
	return (respuesta);
}

void insertar(int fila[], int dato, int *frente, int *final){
	
	if(*final <= 4){
		fila[*final + 1] = dato;
		
		*final = *final + 1;
	
	}
}

void eliminar(int fila[], int *frente, int *final){
	
}

void mostrar(int fila[], int frente, int final){
	
	printf("\nFILA:");
	
	for(int i = final; i >= 0; i--){
		printf("\n\t| %d |", fila[i]);
		printf("\n\t+----+");
		
	}
	
	printf("\nFINAL: %d\n", final);
	printf("\nFRENTE: %d\n", frente);
	
}

int main (){
	int fila[MAX], frente = 0, final = -1;
	
	insertar(fila, 10, &frente, &final);
	insertar(fila, 20, &frente, &final);
	insertar(fila, 30, &frente, &final);
	insertar(fila, 40, &frente, &final);
	
	mostrar(fila, frente, final);
	
	eliminar();
	
	return (0);
}
