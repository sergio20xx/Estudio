﻿using MySql.Data.MySqlClient;
using PCBFabrica.Objetos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCBFabrica.Acceso
{   
    public class DatosComputadores
    {
        public List<Computador> ObtenerTodo()
        {
            List<Computador> Computadores = new List<Computador>();
            Computador com = null;
            MySqlConnection c = Conexion.ObtenerConexion();
            c.Open();
            string query = @"SELECT * FROM computadores";
            MySqlCommand cmd = new MySqlCommand(query, c);
            MySqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                com.Id = r.GetInt32("id");
                com.Modelo = r.GetString("modelo");
                com.Procesador = r.GetString("procesador");
                com.Almacenamiento = r.GetInt32("almacenamiento");
                com.Memoria = r.GetInt32("memoria");
                com.Puertos_usb = r.GetInt32("puerto_usb");
                com.Precio = r.GetInt32("precio");
                com.Marca_id = r.GetInt32("marca_id");

                Computadores.Add(com);
            }
            c.Close();
            cmd.Dispose();
            r.Dispose();
            return Computadores;
        }

        public static long Guardar(Computador com)
        {
            MySqlConnection c = Conexion.ObtenerConexion();
            c.Open();
            string query = @"INSERT INTO computadores (modelo, procesador, almacenamiento, memoria, puertos_usb, precio, marca_id) 
                           VALUES (@modelo, @procesador, @almacenamiento, @memoria, @puertos_usb, @precio, @marca_id)";
            MySqlCommand cmd = new MySqlCommand(query, c);
         
            cmd.Parameters.AddWithValue("@modelo", com.Modelo);
            cmd.Parameters.AddWithValue("@procesador", com.Procesador);
            cmd.Parameters.AddWithValue("@almacenamiento", com.Almacenamiento);
            cmd.Parameters.AddWithValue("@memoria", com.Memoria);
            cmd.Parameters.AddWithValue("@puertos_usb", com.Puertos_usb);
            cmd.Parameters.AddWithValue("@precio", com.Precio);
            cmd.Parameters.AddWithValue("@marca_id", com.Marca_id);
            cmd.ExecuteNonQuery();
            long id = cmd.LastInsertedId;
            c.Close();
            c.Dispose();
            cmd.Dispose();
            return id;
        }
    }
}
