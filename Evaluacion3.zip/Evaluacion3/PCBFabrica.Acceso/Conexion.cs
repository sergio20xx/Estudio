﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCBFabrica.Acceso
{
    class Conexion
    {
        private static string Host = "Localhost";
        private static string Db = "computadores";
        private static string User = "root";

        public static MySqlConnection ObtenerConexion()
        {
            string conString = String.Format("DataSource={0}; Database={1}; Uid={2}", Host, Db, User);
            MySqlConnection conexion = new MySqlConnection(conString);
            return conexion;
        }
    }
}
