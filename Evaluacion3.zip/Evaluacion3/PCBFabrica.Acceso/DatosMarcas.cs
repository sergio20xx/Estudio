﻿using MySql.Data.MySqlClient;
using PCBFabrica.Objetos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCBFabrica.Acceso
{
    public class DatosMarcas
    {
        public static List<Marca> ObtenerTodo()
        {
            List<Marca> Marcas = new List<Marca>();
            Marca m = null;
            MySqlConnection c = Conexion.ObtenerConexion();
            c.Open();
            string query = @"SELECT id, nombre, numero_contrato FROM marcas;
                             SELECT COUNT(*) FROM computadores WHERE marca_id";
            MySqlCommand cmd = new MySqlCommand(query, c);
            MySqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                m = new Marca();
                m.Id = r.GetInt32("id");
                m.Nombre = r.GetString("nombre");
                m.Numero_contrato = r.GetString("numero_contrato");

                Marcas.Add(m);
            }
            c.Close();
            cmd.Dispose();
            r.Dispose();
            return Marcas;
        }
    }
}
