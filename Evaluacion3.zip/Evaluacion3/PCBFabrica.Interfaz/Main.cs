﻿using PCBFabrica.Interfaz.Computadores;
using PCBFabrica.Interfaz.Marcas;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBFabrica.Interfaz
{
    public partial class Main : Form
    {
        private RegistrarProyecto registrarProyectoForm;
        private ListarMarcas listarMarcasForm;
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void registrarProyectoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (registrarProyectoForm == null)
            {
                registrarProyectoForm = new RegistrarProyecto();
                registrarProyectoForm.MdiParent = this;
                registrarProyectoForm.FormClosed += RegistrarProyectoForm_FormClosed;
                registrarProyectoForm.Show();
            }
            else
            {
                registrarProyectoForm.Activate();
            }
        }

        private void RegistrarProyectoForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            registrarProyectoForm = null;
        }

        private void listarMarcasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listarMarcasForm == null)
            {
                listarMarcasForm = new ListarMarcas();
                listarMarcasForm.MdiParent = this;
                listarMarcasForm.FormClosed += ListarMarcasForm_FormClosed;
                listarMarcasForm.Show();
            }
            else
            {
                listarMarcasForm.Activate();
            }
        }

        private void ListarMarcasForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            listarMarcasForm = null;
        }
    }
}
