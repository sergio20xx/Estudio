﻿using PCBFabrica.Acceso;
using PCBFabrica.Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBFabrica.Interfaz.Marcas
{
    public partial class ListarMarcas : Form
    {
        private List<Marca> Marcas = null;
        public ListarMarcas()
        {
            InitializeComponent();
        }

        private void ListarMarcas_Load(object sender, EventArgs e)
        {
            Marcas = DatosMarcas.ObtenerTodo();
            dgMarcas.AutoGenerateColumns = false;
            dgMarcas.DataSource = Marcas;
        }
    }
}
