﻿namespace PCBFabrica.Interfaz.Computadores
{
    partial class RegistrarProyecto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.txModelo = new System.Windows.Forms.TextBox();
            this.txProcesador = new System.Windows.Forms.TextBox();
            this.txAlmacenamiento = new System.Windows.Forms.TextBox();
            this.txMemoria = new System.Windows.Forms.TextBox();
            this.txUSB = new System.Windows.Forms.TextBox();
            this.txPrecio = new System.Windows.Forms.TextBox();
            this.btRegistrar = new System.Windows.Forms.Button();
            this.txId = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Modelo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Procesador";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Almacenamiento";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Memoria";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Puertos USB";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 224);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Precio";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 259);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(137, 256);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(285, 24);
            this.cbMarca.TabIndex = 8;
            this.cbMarca.SelectedIndexChanged += new System.EventHandler(this.cbMarca_SelectedIndexChanged);
            // 
            // txModelo
            // 
            this.txModelo.Location = new System.Drawing.Point(137, 54);
            this.txModelo.Name = "txModelo";
            this.txModelo.Size = new System.Drawing.Size(285, 22);
            this.txModelo.TabIndex = 10;
            // 
            // txProcesador
            // 
            this.txProcesador.Location = new System.Drawing.Point(137, 88);
            this.txProcesador.Name = "txProcesador";
            this.txProcesador.Size = new System.Drawing.Size(285, 22);
            this.txProcesador.TabIndex = 11;
            // 
            // txAlmacenamiento
            // 
            this.txAlmacenamiento.Location = new System.Drawing.Point(137, 123);
            this.txAlmacenamiento.Name = "txAlmacenamiento";
            this.txAlmacenamiento.Size = new System.Drawing.Size(285, 22);
            this.txAlmacenamiento.TabIndex = 12;
            // 
            // txMemoria
            // 
            this.txMemoria.Location = new System.Drawing.Point(137, 156);
            this.txMemoria.Name = "txMemoria";
            this.txMemoria.Size = new System.Drawing.Size(285, 22);
            this.txMemoria.TabIndex = 13;
            // 
            // txUSB
            // 
            this.txUSB.Location = new System.Drawing.Point(137, 190);
            this.txUSB.Name = "txUSB";
            this.txUSB.Size = new System.Drawing.Size(285, 22);
            this.txUSB.TabIndex = 14;
            // 
            // txPrecio
            // 
            this.txPrecio.Location = new System.Drawing.Point(137, 224);
            this.txPrecio.Name = "txPrecio";
            this.txPrecio.Size = new System.Drawing.Size(285, 22);
            this.txPrecio.TabIndex = 15;
            // 
            // btRegistrar
            // 
            this.btRegistrar.Location = new System.Drawing.Point(137, 317);
            this.btRegistrar.Name = "btRegistrar";
            this.btRegistrar.Size = new System.Drawing.Size(109, 40);
            this.btRegistrar.TabIndex = 16;
            this.btRegistrar.Text = "Registrar";
            this.btRegistrar.UseVisualStyleBackColor = true;
            this.btRegistrar.Click += new System.EventHandler(this.btRegistrar_Click);
            // 
            // txId
            // 
            this.txId.Location = new System.Drawing.Point(137, 21);
            this.txId.Name = "txId";
            this.txId.Size = new System.Drawing.Size(285, 22);
            this.txId.TabIndex = 9;
            // 
            // RegistrarProyecto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 400);
            this.Controls.Add(this.btRegistrar);
            this.Controls.Add(this.txPrecio);
            this.Controls.Add(this.txUSB);
            this.Controls.Add(this.txMemoria);
            this.Controls.Add(this.txAlmacenamiento);
            this.Controls.Add(this.txProcesador);
            this.Controls.Add(this.txModelo);
            this.Controls.Add(this.txId);
            this.Controls.Add(this.cbMarca);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RegistrarProyecto";
            this.Text = "Registrar Proyecto";
            this.Load += new System.EventHandler(this.RegistrarProyecto_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.TextBox txModelo;
        private System.Windows.Forms.TextBox txProcesador;
        private System.Windows.Forms.TextBox txAlmacenamiento;
        private System.Windows.Forms.TextBox txMemoria;
        private System.Windows.Forms.TextBox txUSB;
        private System.Windows.Forms.TextBox txPrecio;
        private System.Windows.Forms.Button btRegistrar;
        private System.Windows.Forms.TextBox txId;
    }
}