﻿using PCBFabrica.Acceso;
using PCBFabrica.Objetos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBFabrica.Interfaz.Computadores
{
    public partial class RegistrarProyecto : Form
    {
        public RegistrarProyecto()
        {
            InitializeComponent();
        }

        private void btRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                Computador com = new Computador();
                com.Modelo = txModelo.Text;
                com.Procesador = txProcesador.Text;
                com.Almacenamiento = Int32.Parse(txAlmacenamiento.Text);
                com.Memoria = Int32.Parse(txMemoria.Text);
                com.Puertos_usb = Int32.Parse(txUSB.Text);
                com.Precio = Int32.Parse(txPrecio.Text);
                com.Marca_id = Int32.Parse(cbMarca.Text);
                //com.Valida();
                DatosComputadores.Guardar(com);
                MessageBox.Show("Proyecto registado", "Registro Proyecto", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message, "registrar proyecto", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void RegistrarProyecto_Load(object sender, EventArgs e)
        {
            List<Marca> Marcas = DatosMarcas.ObtenerTodo();
            cbMarca.DataSource = Marcas;
            cbMarca.ValueMember = "id";
            cbMarca.DisplayMember = "nombre";
        }
    }
}
