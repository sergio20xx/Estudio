﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCBFabrica.Testing
{
    public class ExcepcionMarca : ApplicationException
    {
        public ExcepcionMarca() { }
        public ExcepcionMarca(String m) : base(m) { }
        public ExcepcionMarca(String m, Exception e) : base(m, e) { }
    }
}
