﻿using PCBFabrica.Testing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCBFabrica.Objetos
{
    public class Computador
    {
        public long Id { get; set; }
        public string Modelo { get; set; }
        public string Procesador { get; set; }
        public int Almacenamiento { get; set; }
        public int Memoria { get; set; }
        public int Puertos_usb { get; set; }
        public int Precio { get; set; }
        public int Marca_id { get; set; }

        public void Valida()
        {
            if (Modelo.Length < 4 && Modelo.Length > 10)
            {
                throw new ExcepcionMarca ("(" + Modelo +") Largo en Modelo debe de ser Mayor a 3 y Menor a 11");
            }
            if (Memoria < 0)
            {
                throw new ExcepcionMarca("(" + Memoria + ") El valor de memoria debe de ser positivo");
            }
            if (Almacenamiento < 0)
            {
                throw new ExcepcionMarca("(" + Almacenamiento + ") El valor de almacenamiento debe de ser positivo");
            }
            if (Int32.Parse(Procesador) < 10 && Int32.Parse(Procesador) > 100)
            {
                throw new ExcepcionMarca("(" + Procesador + ") El valor de procesador debe de ser positivo");
            }
            if (Puertos_usb > 0)
            {
                throw new ExcepcionMarca("(" + Puertos_usb + ") El valor de los Puertos USB debe de ser positivo");
            }
            if (Precio < 0 && Precio > 100000)
            {
                throw new ExcepcionMarca("(" + Precio + ") Largo en Precio debe de ser Mayor a 0 y Menor a 100.000");
            }
        }
    }
}
