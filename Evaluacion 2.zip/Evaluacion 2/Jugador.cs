using System;

public class Jugador{
	private string Nombres;
	private string PaisOrigen;
	private int Edad;
	private string Posicion;


	public string getNombres(){
		return this.Nombres;
	}

	public string getPaisOrigen(){
		return this.PaisOrigen;
	} 

	public int getEdad(){
		return this.Edad;
	}

	public string getPosicion(){
		return this.Posicion;
	}


	public void setNombres(string Nombres){
		if(Nombres.Length < 6 || Nombres.Length > 25){
			throw new ExcepcionJugador("El jugador debe tener nombre entre 8 y 25 caracteres");
		}
		this.Nombres = Nombres;
	}

	public void setPaisOrigen(string PaisOrigen){
		if(PaisOrigen != "Chile" || PaisOrigen != "Argentina" || PaisOrigen != "Venezuela" || PaisOrigen != "Colombia"){
			throw new ExcepcionJugador("País inválido");
		}

		this.PaisOrigen = PaisOrigen;
	}

	public void setEdad(int Edad){
		if(Edad < 17 || Edad > 34){
			throw new ExcepcionJugador("Edad debe ser mayor o igual a 17 y menor a 35");
		}

		this.Edad = Edad;
	}

	public void setPosicion(string Posicion){
		if(Posicion != "Delantero" || Posicion != "Defensa" 
		   || Posicion != "Portero" || Posicion != "Medio campista"){
			throw new ExcepcionJugador("Posición inválida");
		}

		this.Posicion = Posicion;
	}
}