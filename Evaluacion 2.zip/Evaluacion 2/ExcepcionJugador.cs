using System;

public class ExcepcionJugador : ApplicationException
{
    public ExcepcionJugador() { }
    public ExcepcionJugador(string mensaje) : base(mensaje) { }
    public ExcepcionJugador(string mensaje, Exception e) : base(mensaje, e) { }
}
