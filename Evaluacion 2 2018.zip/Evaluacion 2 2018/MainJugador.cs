using System;

public class MainJugador{
	static void Main(string[] args){
		Jugador j = new Jugador();

		try{
			j.setNombres(args[0]);
			j.setPaisOrigen(args[1]);
			j.setEdad(Int32.Parse(args[2]));
			j.setPosicion(args[3]);

			Console.WriteLine("El jugador ha sido registrado exitosamente");

		}catch(ExcepcionJugador ex){
			Console.WriteLine(ex.Message);

		}catch(FormatException e){
			Console.WriteLine(e.Message);

		}
	}
}