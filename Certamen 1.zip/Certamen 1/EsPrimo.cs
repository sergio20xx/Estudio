using System;

public class EsPrimo{
	static void Main(string[] args){
		try{
			int numero = Int32.Parse(args[0]);
			bool bandera = false;

			for(int i = 3; i < numero; i++){
				if(numero % i == 0){
					bandera = true;
				}
			}

			if(numero == 0 || numero == 1){
				bandera = true;
			}

			if(bandera == true){
				Console.WriteLine(numero + " no es primo");
			}
			if(bandera == false){
				Console.WriteLine(numero + " es primo");
			}

		} catch(FormatException e){
			Console.WriteLine("Error.");

		}
	}
}