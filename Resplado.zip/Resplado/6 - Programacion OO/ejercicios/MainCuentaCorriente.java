public class MainCuentaCorriente {
	public static void main(String[] args) {
		CuentaCorriente cuenta = new CuentaCorriente();
		cuenta.setTitular("Leonardo Farkas");
		cuenta.setSaldo(0); // Saldo inicial en 0

		cuenta.depositar(100000);
		cuenta.depositar(50000);
		System.out.println("Saldo actual: " + cuenta.getSaldo());
		cuenta.depositar(125000);
		cuenta.girar(100000);
		cuenta.girar(40000);

		System.out.println("Saldo final de la cuenta del Sr " + cuenta.getTitular() + " : " + cuenta.getSaldo());
	}
}