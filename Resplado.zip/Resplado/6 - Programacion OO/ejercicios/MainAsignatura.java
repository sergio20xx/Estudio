public class MainAsignatura {
	public static void main(String[] args) {
		Asignatura calculo = new Asignatura();
		calculo.setNombre("Calculo");
		calculo.setAbreviacion("CLC");
		calculo.setHoras(16);
		calculo.setSemestre(2);

		System.out.println("Datos de Calculo");
		System.out.println("Nombre: " + calculo.getNombre());
		System.out.println("Abreviacion: " + calculo.getAbreviacion());
		System.out.println("Horas: " + calculo.getHoras());
		System.out.println("Semestre: " + calculo.getSemestre());
	}
}