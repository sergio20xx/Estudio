public class Evaluacion1{
	public static void main(String[] args) {
		Integer lista[] = new Integer[args.length];

		for (int i = 0; i < args.length; ++i) {
			lista[i] = Integer.parseInt(args[i]);			

		}

		int sumaPar = 0, sumaImpar = 0, cont1 = 0, cont2 = 0;

		for (int i = 0; i < args.length; ++i) {
			if(lista[i] % 2 == 0){
				sumaPar = sumaPar + lista[i];

				cont1++;

			}else{
				sumaImpar = sumaImpar + lista[i];

				cont2++;

			}
		}

		double promPares = (double)sumaPar / cont1; 
		double promImpares = (double)sumaImpar / cont2;

		System.out.println("El promedio de los pares es: " + promPares);
		System.out.println("El promedio de los impares es: " + promImpares);

	}
}