public class CuentaCorriente{
	private String titular;
	private int saldo;

	public CuentaCorriente(){
		this.titular = titular;
		this.saldo = saldo;

	}

	public void setTitular(String titular){ this.titular = titular; }
	public void setSaldo(int saldo){ this.saldo = saldo; }

	public String getTitular(){ return this.titular; }
	public int getSaldo(){ return this.saldo; }

	public void depositar(int monto){
		this.saldo = this.saldo + monto;
		
	}

	public void girar(int monto){
		this.saldo = this.saldo - monto;

	}
}