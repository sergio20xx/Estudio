public class VectorLineal{
	private int capacidad;
	private int valores[] = new int[capacidad];

	public VectorLineal(int capacidad, int valores[]){
		this.capacidad = capacidad;
		this.valores = valores;
	}

	public void setCapacidad(int capacidad){ this.capacidad = capacidad; }
	public void setValores(int[] valores){ this.valores = valores; }

	public int getCapacidad(){ return this.capacidad; }
	public int[] getValores(){ return this.valores; }

	public void mostrar(){
		for(int i = 0; i < capacidad; ++i){
			System.out.println(valores[i]);

		}	
	}

	public int get(int index){
		return valores[index];

	}
}