public class MainColaFifo{
	public static void main(String[] args) {
		ColaFifo cola = new ColaFifo();

		System.out.println(cola.isEmpty());

		cola.push(10);
		cola.push(20);
		cola.push(30);
		cola.push(40);
		cola.push(50);
		cola.pop();
		cola.getPop();
		cola.getPop();

		System.out.println(cola.imprimir());

		System.out.println(cola.isEmpty());

		System.out.println(cola.size());

	}
}