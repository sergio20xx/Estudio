public class MainVectorLineal{
	public static void main(String[] args) {
		int a = 5, b[] = {1, 2, 3, 4, 5};
		VectorLineal vector = new VectorLineal(a, b);

		vector.mostrar();
		
		System.out.println(vector.get(2));

	}
}