public class Asignatura{
	private String nombre;
	private String abreviacion;
	private int horas;
	private int semestre;

	public Asignatura(){
		this.nombre = nombre;
		this.abreviacion = abreviacion;
		this.horas = horas;
		this.semestre = semestre;

	}

	public void setNombre(String nombre){ this.nombre = nombre; }
	public void setAbreviacion(String abreviacion){ this.abreviacion = abreviacion; }
	public void setHoras(int horas){ this.horas = horas; }
	public void setSemestre(int semestre){ this.semestre = semestre; }
	
	public String getNombre(){ return this.nombre; }
	public String getAbreviacion(){ return this.abreviacion; }
	public int getHoras(){ return this.horas; }
	public int getSemestre(){ return this.semestre; }

}