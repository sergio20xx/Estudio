import java.util.ArrayList;

public class ColaFifo{
	private ArrayList<Double> cola = new ArrayList<>();

	public ColaFifo(){
		this.cola = cola;

	}

	public void push(double n){
		this.cola.add(n);

	}

	public boolean isEmpty(){
		if(this.cola.isEmpty()){
			return true;	

		}else{
			return false;

		}
	}

	public int size(){
		return this.cola.size();

	}

	public void pop(){
		if(cola.isEmpty()){
			System.out.println("Error, cola vacia.");

		}else{
			this.cola.remove((this.cola.size()) - 1);

		}
	}

	public void setPop(ArrayList cola){ this.cola = cola; }

	public double getPop(){
		double a = 0;

		if(cola.isEmpty()){
			System.out.println("Error, cola vacia.");

		}else{
			a = this.cola.remove((this.cola.size()) - 1);

		}

		return a;
	}

	public ArrayList imprimir(){
		return this.cola;

	}
}