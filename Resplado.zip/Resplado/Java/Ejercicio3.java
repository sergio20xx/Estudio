import java.util.Scanner;

public class Ejercicio3{
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		System.out.println("Datos a ingresar?: ");
		int cantidad = entrada.nextInt();

		float a[] = new float[cantidad];
		float sum = 0;

		for (int i = 0; i < cantidad; ++i) {
			System.out.println("Ingrese valor " + (i+1) + ": ");
			a[i] = entrada.nextInt();

			sum = sum + a[i];

		}

		System.out.println("\n" + "   " + a[0]);

		for (int i = 1; i < cantidad; ++i) {
			System.out.println(" + " + a[i]);

		}

		System.out.println(" = " + sum);
		

	}
}