import java.util.ArrayList;

public class Demo2{
	public static void main(String[] args) {
		ArrayList<Integer> lista = new ArrayList<>();

		lista.add(1);
		lista.add(2);
		lista.add(3);
		lista.add(new Integer(10));

		for(int i = 0; i < lista.size(); i++) {
			int numero = lista.get(i);

			System.out.println(numero);
			
		}

		int index = lista.indexOf(10);

		if(index != -1) {
			System.out.println("10 exits!");

		}
	}
}