import java.util.ArrayList;
import java.util.Collections;

public class Ejercicio6{
	public static void main(String[] args) {
		ArrayList<String> lista1 = new ArrayList<>();
		ArrayList<String> lista2 = new ArrayList<>();

		boolean bandera = false, remover = false;

		int cont = 0, cantidad = 0;

		for(int i = 0; i < args.length; ++i) {
			if(args[i].contains("-removeIndex") || args[i].contains("-removeObject")) {
				bandera = true;

				if(args[i].contains("-removeIndex")){
					remover = true;

				}

				i++;

			}

			if(bandera == false){
				lista1.add(args[i]);

				cantidad++;

			}else{
				lista2.add(args[i]);

				cont++;

			}
		}

		Collections.sort(lista2);

		if(remover == true) {
			for(int i = 0; i < cont; ++i) {
				lista1.remove(Integer.parseInt(lista2.get(i)));

			}

		}else{
			boolean fin = false;
			int contador = 0;

			do{
				for (int i = 0; i < cont; ++i) {

					String borrar = lista2.get(i);

					if(lista1.remove(borrar)){
						fin = false;

					}else{
						contador++;

					}

					if(contador == cont){
						fin = true;

					}
				}

			}while(fin != true);
		}

		System.out.println("Existen " + cantidad + " elementos en la lista");
		System.out.println("La lista final es " + lista1 + " con " + cont + " elementos");
	
	}
}