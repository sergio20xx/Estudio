import java.util.ArrayList;

public class Ejercicio8{
	public static void main(String[] args) {
		ArrayList<String> lista1 = new ArrayList<>();
		ArrayList<String> lista2 = new ArrayList<>();

		boolean bandera = false;
		int contador = 0, cantidad = 0;

		for (int i = 0; i < args.length; ++i) {
			if(args[i].contains("-remove")){
				bandera = true;

				i++;
				
			}

			if(bandera != true){
				lista1.add(args[i]);

				cantidad++;

			}else{
				lista2.add(args[i]);

				contador++;

			}
		}

		for(int i = 0; i < contador; ++i) {
			lista1.remove(lista2.get(i));

		}

		System.out.println("Existen " + cantidad + " elementos en la lista");
		System.out.println("La lista final es " + lista1 + " con " + (cantidad - contador) + " elementos");

	}
}