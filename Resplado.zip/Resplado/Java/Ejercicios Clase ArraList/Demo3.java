import java.util.ArrayList;

public class Demo3{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();

		lista.add("Caaasdjkasdhka");
		lista.add("asdjasbm");
		lista.add("ll,mads");

		Character a = 'a';

		lista.add(Character.toString(a));

		System.out.println("Cantidad: " + lista.size());

		lista.remove("asdjasbm");

		System.out.println(lista);

		lista.remove(lista.size() - 1);

		System.out.println(lista);

	}
}