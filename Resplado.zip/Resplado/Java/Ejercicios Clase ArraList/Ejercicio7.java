import java.util.ArrayList;

public class Ejercicio7{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();

		boolean bandera = false;
		int contador = 0, fin = 0;
		String buscar = "";
		
		for(int i = 0; i < args.length; i++) {
			if(args[i].contains("-remove")) {
				bandera = true;
				i++;

			}
			if(bandera == true) {
				buscar = args[i];
			
			}else{
				lista.add(args[i]);

				contador++;

			}
		}  

		fin = contador;

		for(int i = 0; i < contador; ++i) {
			if(lista.get(i).contains(buscar)) {
				lista.remove(i);

				contador--;
				i = 0;

			}
		}

		for(int i = 0; i < contador; ++i) {
			if(lista.get(i).contains(buscar)) {
				lista.remove(i);
				contador--;
				
			}
		}

		System.out.println("Existen " + fin + " elementos en la lista");
		System.out.println("La lista final es " + lista + " con " + contador + " elementos");
	}
}