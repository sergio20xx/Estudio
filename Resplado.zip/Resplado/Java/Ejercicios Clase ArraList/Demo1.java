import java.util.ArrayList;

public class Demo1{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();

		lista.add("Jojojo");
		lista.add("Jujuju");
		lista.add("Jijiji");

		System.out.println(lista.isEmpty());

		for(String s : lista) {
			System.out.println(s);
			
		}

		lista.clear();

		System.out.println(lista.isEmpty());
	}
}