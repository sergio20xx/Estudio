import java.util.ArrayList;

public class Ejercicio1{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		String a = " ";

		for(int i = 0; i < args.length; ++i) {
			lista.add(args[i]);

			if(args[i].contains("-indexOf")){
				i++;
				lista.add(args[i]);
				a = lista.get(i);

			}
		}
		
		System.out.println(a + " se encuentra en el indice " + lista.indexOf(a));

	}
}