import java.util.ArrayList;

public class Ejercicio5{
	public static void main(String[] args) {
		ArrayList<String> lista1 = new ArrayList<>();
		ArrayList<String> lista2 = new ArrayList<>();
		boolean bandera = false;

		int cont = 0;

		for(int i = 0; i < args.length; ++i) {
			if(bandera == true){
				lista2.add(args[i]);

				cont++;
				
			}

			lista1.add(args[i]);

			if(args[i].contains("-get")){
				bandera = true;

			}
		}

		for(int i = 0; i < cont; ++i) {
			System.out.println("Elemento " + lista2.get(i) + ": " + lista1.get(Integer.parseInt(lista2.get(i))));

		}

	}
}