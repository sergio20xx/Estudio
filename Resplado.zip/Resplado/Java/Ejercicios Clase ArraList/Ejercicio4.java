import java.util.ArrayList;

public class Ejercicio4{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		String opcion = "", union = "";
		String num = "";

		for(int i = 0; i < args.length; ++i) {
			if(args[i].contains("-p")){
				opcion = "-p";
				num = args[i + 1];

			}else if(args[i].contains("-f")){
				opcion = "-f";
				num = args[i + 1];
			
			}
		}

		switch(opcion){
			case "-p":
				int k = 0;

				for(int i = 0; i < args.length - 2; ++i) {

					for(int j = 0; j < Integer.parseInt(num); ++j) {
						String s1[] = args[k].split("");

						union = union.concat(s1[j]);
						
					}

					k++;

					lista.add(union);

					union = "";

					lista.add(args[i]);

				}

				break;

			case "-f":
				k = 0;

				for(int i = 0; i < args.length - 2; ++i) {

					for(int j = 0; j < Integer.parseInt(num); ++j) {
						String s1[] = args[k].split("");

						int largo = (s1.length - Integer.parseInt(num)) + j;

						union = union.concat(s1[largo]);
						
					}

					k++;

					lista.add(union);

					union = "";

					lista.add(args[i]);

				}

				break;

		}
		

		System.out.println("La lista es: " + lista);

	}
}