import java.util.ArrayList;

public class Ejercicio2{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		String a[] = args[0].split(" ");
		String b[] = args[1].split(" ");

		String s1 = a[0].concat(" ").concat(b[0]);
		String s2 = a[1].concat(" ").concat(b[1]);
		String s3 = a[2].concat(" ").concat(b[2]);

		lista.add(s1);
		lista.add(s2);
		lista.add(s3);

		for(int i = 0; i < 3; ++i) {
			System.out.println("Elemento " + i + ": " + lista.get(i));

		}	
	}
}