import java.util.ArrayList;

public class Ejercicio3{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();

		for(int i = 0; i < args.length; ++i) {
			lista.add(args[i].toUpperCase());

			lista.add(args[i]);
		
		}

		System.out.println("La lista es: " + lista);
	}
}