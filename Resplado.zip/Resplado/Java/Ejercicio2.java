public class Ejercicio2{
	public static void main(String[] args) {
		float a[] = new float[10]; 
		int cont = 0;

		a[0] = 1;
		a[1] = 2;
		a[2] = 3;
		//a[3] = 4;

		for (int i = 0; i < 10; ++i) {
			if(a[i] != 0){
				cont = i;

			}else{
				i = 10;

			}

		}

		float suma = a[0] + a[1] + a[2];

		if(cont > 2){
			System.out.println("Error.");

		}else{
			System.out.println(a[0] + " + " + a[1] + " + " + a[2] + " = " + suma);

		}
	}
}