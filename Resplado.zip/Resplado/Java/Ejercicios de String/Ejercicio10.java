public class Ejercicio10{
	public static void main(String[] args) {
		String cadena = args[0];
		int cont = 0, j = cadena.length() - 1;

		for(int i = 0; i < cadena.length(); ++i) {
			if(cadena.charAt(i) == cadena.charAt(j)) {
				cont++;

			}

			j--;

		}

		if(cont == cadena.length()){
			System.out.println("Si.");
		
		}else {
			System.out.println("No.");

		}
	}
}