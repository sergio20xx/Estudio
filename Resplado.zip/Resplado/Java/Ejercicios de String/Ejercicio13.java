public class Ejercicio13{
	public static void main(String[] args) {
		
	}
}