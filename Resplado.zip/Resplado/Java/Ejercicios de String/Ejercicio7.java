public class Ejercicio7{
	public static void main(String[] args) {
		String cadena1 = args[0];
		String cadena2 = args[1];

		int resultado = cadena1.compareToIgnoreCase(cadena2);

		if(resultado == 0) {
			System.out.println("Si.");

		}else {
			System.out.println("No.");

		}
	}
}