public class Ejercicio4{
	public static void main(String[] args) {
		String cadena = args[0];
		String reemplazado = args[1];
		String reemplazo = args[2];

		System.out.println(cadena.replace(reemplazado, reemplazo));

	}
}