public class Ejercicio6{
	public static void main(String[] args) {
		int mayor = 0, cont1 = 0, cont2 = 0;

		String s1 = args[0];
		String s2 = args[1];

		int largo1 = s1.length(), largo2 = s2.length();

		if(largo1 == largo2){
			mayor = largo1;

		}else{
			System.out.println("No son iguales.");

			System.exit(0);

		}

		for (int i = 0; i < mayor; ++i) {
			if(s1.charAt(i) == s2.charAt(i)) {
				cont1++;
				cont2++;

			}else{
				cont2--;
			
			}
		}

		if (cont1 == cont2) {
			System.out.println("Son iguales.");	

		}else{
			System.out.println("No son iguales.");

		}
	}
}