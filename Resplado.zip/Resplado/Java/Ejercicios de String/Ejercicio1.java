public class Ejercicio1{
	public static void main(String[] args) {
		String cadena = args[0];
		int indice = Integer.parseInt(args[1]);

		if(indice >= cadena.length()){
			System.out.println("Indice invalido.");

			System.exit(0);
		}

		char c = cadena.charAt(indice);

		System.out.println(c);
	}
}