public class Ejercicio3{
	public static void main(String[] args) {
		String cadena = args[0];

		System.out.println("Primero: " + cadena.charAt(0) + "	Segundo: " + cadena.charAt(cadena.length() - 1));

	}
}