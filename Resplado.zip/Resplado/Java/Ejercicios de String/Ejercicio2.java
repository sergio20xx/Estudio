public class Ejercicio2{
	public static void main(String[] args) {
		int indice1 = Integer.parseInt(args[2]);
		int indice2 = Integer.parseInt(args[3]);

		String cadena1 = args[0];
		String cadena2 = cadena1 + args[1];

		if(indice1 > -1 && indice2 <= cadena2.length() + 1){
			cadena2 = args[1];
			String espacio = " ";

			System.out.println(cadena1.concat(espacio).concat(cadena2).substring(indice1, indice2));
		
		}else{
			System.out.println("Indice invalido.");

			System.exit(0);

		}
	}
}