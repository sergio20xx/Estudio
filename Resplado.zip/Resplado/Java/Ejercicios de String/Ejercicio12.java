public class Ejercicio12{
	public static void main(String[] args) {
		String cadena1 = args[0];
		String cadena2 = args[1];

		if(cadena2.startsWith(cadena1)){
			System.out.println("Prefijo.");

		}else if(cadena2.endsWith(cadena1)){
			System.out.println("Sufijo.");

		}else{
			System.out.println("Nada.");

		}
	}
}