public class Ejercicio5{
	public static void main(String[] args) {
		String cadena1 = args[0];
		String cadena2 = args[1];

		if(cadena1.contains(cadena2)){
			System.out.println("Si.");

		}else {
			System.out.println("No.");

		}
	}
}