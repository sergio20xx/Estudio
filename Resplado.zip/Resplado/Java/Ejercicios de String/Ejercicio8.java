public class Ejercicio8{
	public static void main(String[] args) {
		String cadena = args[0];
		int largo = cadena.length(), consonantes = 0, espacios = 0, vocales = 0;

		for(int i = 0; i < largo; ++i) {
			char c = cadena.charAt(i);

			if(Character.isLetter(c)){
				consonantes++;

			}

			if(Character.isWhitespace(c)) {
				espacios++;

			}

			if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
				vocales++;

			}
		}

		consonantes = consonantes - vocales;

		System.out.println("vocales: " + vocales + ", consonantes: " + consonantes + ", espacios: " + espacios);

	}
}