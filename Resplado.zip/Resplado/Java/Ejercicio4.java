import java.util.Scanner;

public class Ejercicio4{
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		int num, prom;

		do{
			System.out.println("Ingrese un numero de dos digitos: ");
			num = entrada.nextInt();

			if(num > 99 || num < 10){
			System.out.println("\n" + "Error, ingrese valor valido. \n");

			}

		}while(num > 99 || num < 10);

		int valor1 = num / 10;
		int valor2 = num % 10;

		if(valor1 % 2 == 0 && valor2 % 2 == 0){
			prom = (valor1 + valor2) / 2;

			System.out.println("\n" + "El promedio es: " + prom);

		}else{
			System.out.println("\n" + "Los numeros no son pares.");

		}
	}
}