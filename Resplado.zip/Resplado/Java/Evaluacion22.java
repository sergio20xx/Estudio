import java.util.ArrayList;

public class Evaluacion22{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		String tipo = "";
		int menor = Integer.parseInt(args[1]), mayor = Integer.parseInt(args[1]), indice = 0;

		tipo = args[0];

		for(int i = 1; i < args.length; ++i) {
			lista.add(args[i]);

			if(tipo.contains("-menor")){
				if(Integer.parseInt(args[i]) < menor){
					menor = Integer.parseInt(args[i]);

				}
			}else if(tipo.contains("-mayor")){
				if(Integer.parseInt(args[i]) > mayor){
					mayor = Integer.parseInt(args[i]);

				}
			}
		}

		if(tipo.contains("-menor")){
			System.out.println("El numero menor es " + menor + " y se encuentra en la posicion " 
				+ lista.indexOf(Integer.toString(menor)));
		
		}else if(tipo.contains("-mayor")){
			System.out.println("El numero mayor es " + mayor + " y se encuentra en la posicion " 
				+ lista.indexOf(Integer.toString(mayor)));

		}
	}
}