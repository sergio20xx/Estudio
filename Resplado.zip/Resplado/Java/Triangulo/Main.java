public class Main{
	public static void main(String[] args) {
		Triangulo t1 = new Triangulo(1, 4, 8);

		System.out.println("Lado 1: " + t1.getLado1());
		System.out.println("Lado 2: " + t1.getLado2());
		System.out.println("Lado 3: " + t1.getLado3());
		System.out.println("Perimetro: " + t1.getPerimetro());
	}
}