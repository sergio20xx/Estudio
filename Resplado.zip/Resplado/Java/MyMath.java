import java.util.Scanner;

public class MyMath{
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		System.out.println("Ingrese un numero: ");
		int numero = entrada.nextInt();

	}
}