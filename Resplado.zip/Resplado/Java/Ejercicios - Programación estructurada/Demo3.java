import java.util.ArrayList;

public class Demo3{
	public static void main(String[] args) {
		ArrayList<Integer> numero = new ArrayList<Integer>();

		numero.add(1);
		numero.add(0);
		numero.add(1);
		numero.add(0);
		
		for(int i = 0; i < numero.size(); ++i){
			System.out.println(numero.get(i));

		}

	}
}