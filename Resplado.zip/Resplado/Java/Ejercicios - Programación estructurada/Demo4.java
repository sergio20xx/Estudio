import java.util.ArrayList;

public class Demo4{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		//Verificamos si tiene elementos
		if(lista.isEmpty()){
			System.out.println("La lista esta vacia.");
		
		}	

		//Insertamos 5 elementos
		lista.add("hahahaha");
		lista.add("jijijiji");
		lista.add("jujujuju");
		lista.add("jojojojo");

		System.out.println(lista);
		
	}
}