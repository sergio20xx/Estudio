public class Demo2{
	public static void main(String[] args) {
		String s1 = new String("Hola Mundo");
		String s2 = new String("Hola Mundo");

		if(s1.equals(s2)){
			System.out.println("Iguales???");

		}else{
			System.out.println("Distintos???");

		}

		System.out.println(s1.concat(s2));

		int uno = 1, otroUno = 1;

		if(uno ==otroUno){
			System.out.println("Iguales???");

		}else{
			System.out.println("Distintos???");

		}
	}
}