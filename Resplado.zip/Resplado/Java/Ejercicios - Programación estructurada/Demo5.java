import java.util.ArrayList;

public class Demo5{
	public static void main(String[] args) {
		ArrayList<String> lista = new ArrayList<>();
		//Agregamos 3 elementos
		lista.add("Goku");
		lista.add("Piccoro");
		lista.add("Krilin");
		//Existe "Piccoro"
		if(lista.contains("Piccoro")){
			System.out.println("Piccoro exist.");

		}
		//Reemplazo el elemento en el indice 1
		lista.set(1, "Bulma");
		//Inserto en posición intermedia
		lista.add(1, "Kame Sennin");

		lista.remove("Bulma");

		System.out.println(lista);

	}
}