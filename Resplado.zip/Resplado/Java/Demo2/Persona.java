public class Persona{
	private String nombres;
	private int edad;

	public Persona(String nombres, int edad){
		this.nombres = nombres;
		this.edad = edad;

	}

	public String getNombres(){ return this.nombres; }
	public int getEdad() { return this.edad; }

	public void setNombres(String nombres){ this.nombres = nombres; }
	public void setEdad(int edad){ this.edad = edad; }

	public boolean equals(Object o){
		Persona s = (Persona)o;

		return this.nombres.equals(s.nombres);

	}

	public String toString(){
		return this.nombres + ", " + this.edad + " años";

	}
}