import java.util.ArrayList;

public class Main{
	public static void main(String[] args) {
		Persona p1 = new Persona("Goku", 100);
		Persona p2 = new Persona("Goku", 100);
		Persona p3 = new Persona("Calamardo", 1000);

		ArrayList<Persona> lista = new ArrayList<>();
		lista.add(p1);

		System.out.println(lista.contains(p2));

		if(p1.equals(p2)){
			System.out.println("Son la misma cuestion.");

		}else{
			System.out.println("Son cuestiones diferentes.");

		}

		System.out.println(p1);
		System.out.println(p2);

	}	
}