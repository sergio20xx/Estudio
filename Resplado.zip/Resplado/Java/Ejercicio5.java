import java.util.Scanner;

public class Ejercicio5{
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		System.out.println("Cantidad de datos a ingresar: ");
		int cantidad = entrada.nextInt();

		double arreglo[] = new double[cantidad]; 

		System.out.println("\n");

		for(int i = 0; i < cantidad; ++i){
			System.out.println("Ingrese valor " + (i + 1) + ": ");
			arreglo[i] = entrada.nextDouble();

		}

		double menor = arreglo[0];

		for (int i = 1; i < cantidad; ++i) {
			if (arreglo[i] < menor){
				menor = arreglo[i];		
			
			}
		}

		System.out.println("\n" + "El menor es: " + menor);

	}
}