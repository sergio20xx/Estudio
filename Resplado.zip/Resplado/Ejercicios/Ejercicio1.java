package javaBasico;

import java.util.Scanner; 

public boolean isNumeric(String s) {
    int len = s.length();
    for (int i = 0; i < len; ++i) {
        if (!s.charAt(i).isNumeric()) {
            return false;
        }
    }
  
    return true;
}

public class Ejercicio1 {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in); 

		int v1;
		int v2;
		int a;
		int b;

		do{
			System.out.println("\n" + "Ingrese valor de a: ");
			a = entrada.nextInt();

			if(Comunes.isNumeric(a)){
				v1 = 0;

			}else{
				v1 = 1;

			}

			System.out.println("Ingrese el valor de b: ");
			b = entrada.nextInt(); 

			if(Comunes.isNumeric(b)){
				v2 = 1;

			}else{
				v2 = 0;
			}

			if(v1 + v2 > 0){
				System.out.println("\n" + "Error, ingrese valores nuevamente." + "\n" + "//////////////////////////////////");

			}

		}while (v1 + v2 > 0);

		int suma = a * a - b * b;

		System.out.println("\n" + "La resta al cuadrado de a + b es: " + suma + "\n");

	}
}
