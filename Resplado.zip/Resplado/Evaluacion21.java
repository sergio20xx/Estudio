public class Evaluacion21{
	public static void main(String[] args) {
		String nombre = args[0];
		String email =  args[1];
		int edad = Integer.parseInt(args[2]), cont1 = 0, cont2 = 0, cont3 = 0;
		boolean validaMail = false;

		if(edad <= 99 && edad >= 0){
			for(int i = 0; i < nombre.length(); ++i) {

				char a = nombre.charAt(i);

				if(Character.isLetter(a) || Character.isWhitespace(a)){
					if(Character.isWhitespace(a)) {
						cont1++;

						if(cont1 == 2){
							System.out.println("Hay mas de un espacio");

							System.exit(0);

						}

					}else{
						cont2++;

					}

					if(cont1 == 1 && Character.isLetter(a)){
						cont3++;

					}

				}else{
					System.out.println("Ni el nombre ni el apellido de la persona pueden contener digitos");

					System.exit(0);
				
				}
			}

			if(cont1 + cont2 == nombre.length() && cont1 == 1 && cont3 == 1){
				for(int i = 0; i < email.length(); ++i) {
					char a = email.charAt(i);

					if(a == '@' && i > 0) {
						validaMail = true;

					}
				}

				if((email.contains("@gmail.com") || email.contains("@hotmail.com")) && validaMail == true && email.endsWith(".com")){
					System.out.println("Datos correctamente ingresados");

				}else{
					System.out.println("Email invalido");

					System.exit(0);

				}

			}else{
				System.out.println("Falta el apellido");
				
				System.exit(0);

			}

		}else{
			System.out.println("Edad invalida");

			System.exit(0);

		}
	}
}