public class Cuadrado{
	private double lado;

	public Cuadrado(){
		this.lado = lado;

	}

	public void setLado(double lado){ this.lado = lado; }

	public double getLado(){ return this.lado; }

	public double getArea(){
		return lado * lado;

	}

	public double getPerimetro(){
		return 4 * lado;

	}
}