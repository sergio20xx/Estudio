public class Circulo{
	private double radio;

	public Circulo(){
		this.radio = radio;
	
	}

	public void setRadio(double radio){ this.radio = radio; }

	public double getRadio(){ return this.radio; }

	public double getArea(){
		return Math.PI * radio * radio;

	}

	public double getPerimetro(){
		return 2 * Math.PI * radio;

	}
}