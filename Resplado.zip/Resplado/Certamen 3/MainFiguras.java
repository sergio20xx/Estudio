public class MainFiguras {
	public static void main(String[] args) {
		Circulo c1 = new Circulo();
		c1.setRadio(4.5);
		double area_c1 = c1.getArea();
		double perimetro_c1 = c1.getPerimetro();

		System.out.println("Area del circulo de radio " + c1.getRadio() + " : " + area_c1);
		System.out.println("Perimetro del circulo de radio " + c1.getRadio() + " : " + perimetro_c1);

		Cuadrado c2 = new Cuadrado();
		c2.setLado(7.8);
		double area_c2 = c2.getArea();
		double perimetro_c2 = c2.getPerimetro();

		System.out.println("Area del cuadrado de lado " + c2.getLado() + " : " + area_c2);
		System.out.println("Perimetro del cuadrado de lado " + c2.getLado() + " : " + perimetro_c2);
	}
}