public class D4 {
	public static void main(String[] args) {
		String l1 = "Hello";

		for(int i = 0 ; i < l1.length(); ++i){
			System.out.println(l1.charAt(i) + "\n");

		}

		String l2 = l1 + "!";

		int ll2 = l2.length();

		System.out.println("\n" + "Existe" + ll2);

		int indiceM = l1.indexOf("M");
		if (indiceM != -1) {
			System.out.println("\n" + "Existe M");
			
		}

		System.out.println(l1.concat("\n" + "Buuu"));

	}

}
