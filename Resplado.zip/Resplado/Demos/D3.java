public class D3 {
	public static void main(String[] args) {
		for(int i = 0; i < 0; i++){
			System.out.println("" + i);

		}

		int j = 0;

		while(j++ < 10){
			System.out.println("" + j);

		}

		int k = 6;
		switch(k){
			case 1:
				System.out.println("\nJajaja");
				break;

			case 3:
				System.out.println("\nHahaha");
				break;

			case 6:
				System.out.println("\nJijiji");

		}

		String l1 = "Hello";
		switch(l1){
			case "Hello":
				System.out.println("\nJujuju");
				break;

		}

	}
}
