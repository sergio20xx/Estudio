public class D2 {
	public static void main(String[] args) {
		int numero = 1;
		double f = 3.6;
		double suma = numero + f;

		System.out.println("" + suma);	
		
		boolean esVerdadero = false;	

		if(! esVerdadero){
			System.out.println("Siempre entra.");

		}else{
			System.out.println("None here.");

		}
	}	
}
