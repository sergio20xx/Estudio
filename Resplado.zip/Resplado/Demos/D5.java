public class D5 {
	public static void main(String[] args) {
		String l1 = "Hello world";
		String p = l1.substring(1, 5);

		System.out.println(p + "\n");

		if (l1.endsWith("world")) {
			System.out.println("World finished" + "\n");
			
		}

		String n = l1.replace('z', 'w');
		System.out.println(n + "\n");
		String pf  = l1.split(" ")[1];
		System.out.println(pf + "\n");

		System.out.println(l1.toUpperCase() + "\n");

	}
}
