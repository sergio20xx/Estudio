public class D6 {
	public static void main(String[] args) {
		String operation = args[0];

		int l1 = Integer.parseInt(args[1]);
		int l2 = Integer.parseInt(args[2]);

		switch(operation){
			case "+":
				int sum = l1 + l2;
				System.out.println(sum);

				break;

			case "-":
				int rest = l2 - l1;
				System.out.println(rest);

				break;

		}
	}
}