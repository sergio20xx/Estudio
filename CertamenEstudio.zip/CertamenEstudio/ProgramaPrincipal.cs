using System;

public class ProgramaPrincipal{
	static void Main(string[] args){
		Persona p = new Persona;

		try{
			p.SetRut(args[0]);
			p.SetEdad(Int32.Parse(args[1]));

			Console.WriteLine("Datos cambiados");

		}catch(PersonaException e){
			Console.WriteLine(e.Message);
		}
	}
}